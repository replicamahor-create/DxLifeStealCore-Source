package dev.dxlifesteal;

import dev.dxlifesteal.commands.DxLifeStealCommand;
import dev.dxlifesteal.database.DatabaseManager;
import dev.dxlifesteal.gui.RecipesGUI;
import dev.dxlifesteal.listeners.*;
import dev.dxlifesteal.managers.*;
import dev.dxlifesteal.placeholders.DxPlaceholderAPI;
import dev.dxlifesteal.tasks.AutoSaveTask;
import dev.dxlifesteal.tasks.EventTask;
import dev.dxlifesteal.utils.ColorUtil;
import dev.dxlifesteal.utils.LicenseManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bstats.bukkit.Metrics;

public class DxLifeStealCore extends JavaPlugin {

    private static DxLifeStealCore instance;

    // Managers
    private HeartManager heartManager;
    private EliminationManager eliminationManager;
    private ItemManager itemManager;
    private EventManager eventManager;
    private LeaderboardManager leaderboardManager;
    private DatabaseManager databaseManager;
    private LicenseManager licenseManager;
    private ConfigManager configManager;
    private MessageManager messageManager;
    private DiscordManager discordManager;
    private CooldownManager cooldownManager;
    private StreakManager streakManager;
    private dev.dxlifesteal.managers.RecipeManager recipeManager;

    @Override
    public void onEnable() {
        instance = this;

        // Save default configs
        saveDefaultConfig();
        saveResource("messages.yml", false);

        // Init config manager first
        configManager = new ConfigManager(this);
        messageManager = new MessageManager(this);

        // Print startup banner
        printBanner();

        // License check
        licenseManager = new LicenseManager(this);
        if (!licenseManager.validate()) {
            getLogger().severe("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            getLogger().severe("  INVALID LICENSE KEY!");
            getLogger().severe("  Get your license at: https://dxlifesteal.dev");
            getLogger().severe("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        // Init database
        databaseManager = new DatabaseManager(this);
        if (!databaseManager.initialize()) {
            getLogger().severe("Failed to connect to database! Disabling plugin.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        // Init all managers
        heartManager = new HeartManager(this);
        eliminationManager = new EliminationManager(this);
        itemManager = new ItemManager(this);
        eventManager = new EventManager(this);
        leaderboardManager = new LeaderboardManager(this);
        discordManager = new DiscordManager(this);
        recipeManager = new dev.dxlifesteal.managers.RecipeManager(this);
        recipeManager.registerRecipes();
        cooldownManager = new CooldownManager(this);
        streakManager = new StreakManager(this);

        // Register commands
        getCommand("dxlifesteal").setExecutor(new DxLifeStealCommand(this));
        getCommand("dxlifesteal").setTabCompleter(new DxLifeStealCommand(this));

        // Register listeners
        registerListeners();

        // Register PlaceholderAPI
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new DxPlaceholderAPI(this).register();
            getLogger().info("PlaceholderAPI hooked successfully!");
        }

        // Start tasks
        new AutoSaveTask(this).runTaskTimer(this, 20L, 20L);
        new EventTask(this).runTaskTimer(this, 20L, 20L);

        // bStats
        if (configManager.isMetricsEnabled()) {
            new Metrics(this, 12345);
        }

        getLogger().info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        getLogger().info("  DxLifeStealCore v" + getDescription().getVersion() + " by DipuXPro");
        getLogger().info("  Status: ACTIVE ✓");
        getLogger().info("  Database: " + configManager.getDatabaseType());
        getLogger().info("  License: VALID ✓");
        getLogger().info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    @Override
    public void onDisable() {
        if (heartManager != null) heartManager.saveAll();
        if (databaseManager != null) databaseManager.close();
        getLogger().info("DxLifeStealCore disabled. Data saved.");
    }

    private void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new PlayerDeathListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerQuitListener(this), this);
        Bukkit.getPluginManager().registerEvents(new HeartItemListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerRespawnListener(this), this);
        Bukkit.getPluginManager().registerEvents(new RecipesGUI(this), this);
    }

    private void printBanner() {
        getLogger().info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        getLogger().info("  ____        _     _  __      ____  _             _ ");
        getLogger().info(" |  _ \\ _  _| |   (_)/ _| ___/ ___|| |_ ___  __ _| |");
        getLogger().info(" | | | \\ \\/ / |   | | |_ / _ \\___ \\| __/ _ \\/ _` | |");
        getLogger().info(" | |_| |>  <| |___| |  _|  __/___) | ||  __/ (_| | |");
        getLogger().info(" |____//_/\\_\\_____|_|_|  \\___|____/ \\__\\___|\\__,_|_|");
        getLogger().info("                                      by DipuXPro");
        getLogger().info("  Version: " + getDescription().getVersion());
        getLogger().info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    public void reload() {
        reloadConfig();
        configManager.reload();
        messageManager.reload();
        itemManager.reload();
        heartManager.reload();
        eliminationManager.reload();
        discordManager.reload();
        recipeManager.unregisterRecipes();
        recipeManager.registerRecipes();
    }

    // Getters
    public static DxLifeStealCore getInstance() { return instance; }
    public HeartManager getHeartManager() { return heartManager; }
    public EliminationManager getEliminationManager() { return eliminationManager; }
    public ItemManager getItemManager() { return itemManager; }
    public EventManager getEventManager() { return eventManager; }
    public LeaderboardManager getLeaderboardManager() { return leaderboardManager; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public LicenseManager getLicenseManager() { return licenseManager; }
    public ConfigManager getConfigManager() { return configManager; }
    public MessageManager getMessageManager() { return messageManager; }
    public DiscordManager getDiscordManager() { return discordManager; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public StreakManager getStreakManager() { return streakManager; }
    public dev.dxlifesteal.managers.RecipeManager getRecipeManager() { return recipeManager; }
}
