package dev.dxlifesteal.utils;

import dev.dxlifesteal.DxLifeStealCore;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

public class LicenseManager {

    private final DxLifeStealCore plugin;
    private boolean valid = false;

    // -------------------------------------------------------
    //   ALL VALID LICENSE KEY HASHES - DipuXPro
    //   DO NOT SHARE - SHA-256 hashed
    // -------------------------------------------------------
    private static final Set<String> VALID_HASHES = new HashSet<>(Arrays.asList(
        "a570bacec2cef5451588a10a4efd68e4f4e6c1de2d90c37bc9fc2ac3dd04f569",
        "c97f83083dbd288e148ea7a53d2ae5b76373a110f3765e4dc9e09aaec09ea1e4",
        "258172c1a88a104ec3a6d13788aa61a5adbb0ab90c2d0345f4bd744cdad5b627",
        "ecee6141b89af301bbf1912855cdbda9448c8d08092c1af158dfee252bf5a01a",
        "d495b9686682ca94be83831722a2035a522617e378f8a20b1106a944b90a2132",
        "ead307c65dcb4302c4b0cf15fe0be9da12ccf60d65e1dfd48135ca2ebe863f36",
        "f91fb2d44ea46848ae0222c1cf68906f562d13bce077c8f779b7737f01920a2a",
        "0525903e0770b7fddb1eda103cb06524e334b2df8c75ab53eda27157b43d087c",
        "c116b61bed5471bec7a4772eb7bc35c326810db56dbd6a9e45fdfea94d924192",
        "0c3f2399f13b4452bca457f30792da272236dd12a4511c03eaa55e7d7ca82b8e",
        "129c7e5774ac5a85fee9e08fc2b3cd927d906ddf668861b941768b3bc3f123cc",
        "84a539dcdb1773810f8ea422489606753c48941adc21e9a0ceea785e2fa7982f",
        "fb665e2ed025dc25b4d46d0e06b649fee5d8ed520f835af497e34e9c42266645",
        "90a173b34e63205762e5c58143f8c4d8b6ef164c7328c03b7d6c781c168527e3",
        "1332a294066d199288070590dd4d8d9a9945d0395d79e70f1dbebbff51b2c5a0",
        "3a708ebe1aad296102fac2d8843c3054e6a5a768adf17589a3035b340cd18ae8",
        "7d8868b6b6de21efe89ad87fcfed2ee84ebda3bf00660510b55b458f552d8ed5",
        "048acf0d852395ec2ba90a52a90ca7e6d71ec58364e18c34d594d76afb368bf7",
        "cd8b91a5059b4ed000323633ad3ac5c46ee6219dfde24fdc7899637583632c06",
        "0da9f4c1f45c1729d725239d7d9b842065187caa1bdc988c02518ef578be687c",
        "0e097a0dbcdacf794060a763c6eedc71f60248e838dceb625b9b66bfcbc727f0",
        "36886c0f660fef3a01eb0ff55968a45e479dea0b8e4263ee8feafaf9a91fa143",
        "ee3381e526c6d31f62a0eb523bf184281af2e353a6e4de24ce23214b83a39b7e",
        "7d7a452bd08831cf48477d544ec636564cbcaf983ba0a514ecf6c90d12b9f6db",
        "e2bcb2125d681956e7374c5364a646b6815979ef77415cd452e8d7e616b03121",
        "0d0b8915430a9a48f2fa2c26400fcf767cf253f4c98d79fc58628baba0cb4c4f",
        "4c78b7d4906450a9f2338713da5a96464ef09f3bc383fbb4c1e9d1383f4d1953",
        "f15c1300fe7730c6a6993b2e51a5d110998aeb58a599baa7a88b53c4689e779e",
        "739bc9ec031f787b5a03b31953fe709fbb6da71f135948fbe00fde0db51f5b5a",
        "f2efc6fc18a2e9d8374b84a580dc80c8c4a0975c94926daa5667a34821eb39fe",
        "93cc565e7f94354e06a6465f42959b57efa6f90ef18a30a3ad298ac6cabb390b",
        "46453da7a507cd6a84f42a07a54a204c29c1d1ee4d8efff758433f11c8f428a3",
        "40346a659bcb6ea6b418dc5523e78831dd148551348a88976994124de24f75c1",
        "6373f371010140369114810e962886cf20b5fa9af64430b0ca629216a5c9f1ec",
        "1bce19c88bf5353a107ee25334d3729a6935c8515465f3317581d2fec22a1b4a",
        "a1a3491b0f2318b6b8ef3d65b3b8509878c26091862f978c10e3255971424503",
        "128356b1d35500e30830adccd2ab9c41df65117e03d6adcf7fb95e8bf08267d3",
        "f7c09787c91782942bfe5e454f845f8b629178f054605d9eb3c57c6d27fe7e24",
        "b2791b00f73b2a84015a484360ddd3b570ed32b0c76245e06426a8cb1db42ba7",
        "17d83012afa610d0b867b57004c4969449626812285e53ba3b62cc2d23bc9a92",
        "4a34da584ee77601be16f83b6940cb068586fab1d047ba0a43f3e3229876d2f3",
        "66278477e648eb05966786f92f49a99bf8b4eee878589ba5304663ec017797e6",
        "7c1a62681d69f970f7635ddf43a8302813975f81bf77e620307affe37903099b",
        "d536eca871d81152166e8aed8831ab27f5db3f8dfb7659498860782fee1e2750",
        "945ea198acd5b5758865a8373769bfcdf5ca3d7aacbe474de8807fd460ea433b",
        "518197225ebb94bb7022185622347f3ffa3b92e9eb7962734cf70937ef0e5d82",
        "6b9e1374c91a0968ad4265a1e67db73d5c563bf6dc0e439ec2ae356958c59866",
        "e86d12343286d8cfa4cc9508f726432022358704bdeeca37f1fac2dd100ef1ad",
        "72b99f933a7c4a11b3c71d4b19d345dbbdaa75ca27b6acda043589a3dc91c249",
        "d16473227f68858cee7e9dd48d959063f395fba65b3b14a24cbc7c3ab8e947b5",
        "702a9dbb508b970a1da7bd79bdf2ff700b064550f1fd0d5d6185d974c3bdb3af",
        "82a71302ffc3a9e5a1e4d7d9b964f2e321bf53e610327e998b0fc95ff20639b1",
        "908c26b11326d5945cef61264d23d74a6b92bc9078e571fedd8407f35626154d",
        "27df7d7f63338ca9e1e5ea90a1c552a6155001165e7de8130465b0c26f383f26",
        "1fd692ace0fe4686f12db3a63b97bebd1cbdd897649d48b8949efe5a6fa054d5",
        "607036173b8a97ee997d965c4235897cfb9995dfc06bfec743229ef62373c146",
        "1c94963d68981936bae937f1a1050069c7e3d150a5200822b2184d7f7757acfc",
        "af179ab2410eeade4ba440f3c444fd612754a9450835ceef5e9b95e065d11014",
        "111f6cd4b3ba8388911e7b6f984fce393299b853150d6d92437daf5c00d7ffc1",
        "9e8593a5df08edfa1ff87b12c9c180f5719baca377c63cdc4ade7bf1d36726cb",
        "86a334cdc2515bfa07ce9853427df09b482acbd87ac0f8063875d4ef558c9e9e",
        "e981300545f3e6057e87f8f12d498a71c12191015d067c0ab72297215acb1b72",
        "1801a67007b6d7a3dabbab2ffa8db016b3c14015f8b3909c283e993e68874d66",
        "c2974ffaa3399dc049b85920d340e2235b2972e77d8f5a906637a8a9b468b8ee",
        "2af14d2c5a1ac6137dd1959c64b9f869eff9da47a361c143e8d3e52a58595484",
        "33ebc38c5dc04f0a4b3c285b5bfc711dbcfdb00f2133dabd98a6cc9261a7a5a8",
        "907da93e859adde2e258f83ecdf45e6d2d53e3824cd63582370cc675e98cbbd6",
        "c30d418df89efc2297d45f341688bdf49ed24e28c6c45a4321cced4ded99cc82",
        "de1acd68aabaac8c79e2e0cd77ea738e1412ba1f4fbaedcf3b1ff84f40da800f",
        "86bbcc4b7593511675ed6c0733f04456f1ceb6ea699a10b7422c700cdc096fb4",
        "f41261c569239d2e83e5e714d480de03dd95769084b1b58d3de0988fb931cdc9",
        "1b0347384bcc06543c0ae6c38fe8d5af7db63c0b52fb824f13137137affa79be",
        "d9a612646f5b23118bd45adf2d767be6dc38fe351ea80f508fed8ab656211253",
        "d3efd6763c852d7ae04620e3d21d848f0771dbe4909944b5771eada1bda0c5aa",
        "f9db1a26cb1c34b9483b3fdc8b4756e28357697f6ed6f0c662c0f676040c633e",
        "fcd83067fce0b25822e2d33e9d4b9f9134d9d52d1f6284cd19b004bc41ea1b8d",
        "a645e097d22d9a1d91c053cb64f2b57b6e65266b5e4ffa795fd345859e62b7fe",
        "f576f32fd02f48cb4f4ee155076bfc02554147ba063dd180b0613b7afa823abc",
        "1ec4e060bf857f309ca3ebf4d696f1e7a42239df08d773a4f22c422ed6907c6d",
        "0b9b2e8c512c390efcb3e101fed1c2b733d4d724067d2796d1f50b46c57bbace",
        "6ce6e4fa943107c64d2c25c8a0866e6db613e91be8ccf4521d108b7da33a7784",
        "adf691dcacdcdf681a8500cee4dd6273d1a4c89bd90bde125218b52abe62d399",
        "5024c9d90cd3553f3a86f1125f137d558134e8a7d787ef7d95eb1ca6af7c1b07",
        "94ed464b21a448bbc509f882eeef3bfdd10f45ac5ae5f4e0d1f6bc0cc9dc74cd",
        "bef20ffa0247cc57c0fe418153a9ceccfac2950bbc45600ff6478a479a33f248",
        "5e06f312d8839e492003a5fad30ea71f256fe8fa3fec99a3da541a31c2b6348e",
        "6ef6ae36c1b748627fe95def1dc551e1cb97ed54a1bad0f66daab5bd2f484594",
        "86518cf56ea42bf84404ab9600a967f49a76767379a8294e32133648b76a4524",
        "aa33ac75005745c46e9f362c92cd64f3cd3cf8d29a4ccb7409f57bbb8cf17429",
        "e4561f0e28852855b5f26b41b31699861c4b0f5e7422271e9efdf7840185bcc5",
        "6f54358ecfd7a6d2185628cf74d82ceef1974c8ec263d2d3703510ebf50518c7",
        "d59135471641654c499616bbd3a35229065245218640e27b11df2f6353776d44",
        "2be9777890bd008f656e81b0effe5b1529ce9012f4b88caf9eea3a54d0690655",
        "ce0a5e124f0e6a852613138f66c811f277d5b180fd345187417b02dd7e576ebf",
        "2bcd57ca347d7e5a3bcc25824d42b19393452f0b1376ff6ea652f5339894980e",
        "693e9a82b30c6cfac1903c6718c4fbdc492fd6409852d32bd6a9fff5e4feca22",
        "1787e0d4d3cbe1fefdce8f837b5da28a912bb959bce00954fe892740ddb743e0",
        "c7c60ff40bf9a82d1447ab6769645f712010b3a2eaf5098cdc0d60abe4f5012e",
        "2f1447fa9348792a91135fc6e81b1d9c97ecd8f81ad6363b0a66b8a484df47f6",
        "168b5975fe6856e75a30489ad395c28ae522761faa3d6de3c90d8de6d24c1d39"
    ));

    public LicenseManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public boolean validate() {
        String configKey = plugin.getConfigManager().getLicenseKey();

        if (configKey == null || configKey.trim().isEmpty()) {
            printInvalidBanner("No license key set in config.yml!");
            return false;
        }

        String normalized = configKey.trim().toUpperCase();

        if (isValidKey(normalized)) {
            valid = true;
            plugin.getLogger().info("[DxLifeStealCore] License validated successfully! ✓");
            return true;
        } else {
            printInvalidBanner("Invalid key: " + maskKey(configKey));
            return false;
        }
    }

    private boolean isValidKey(String key) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(key.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : hashBytes) hex.append(String.format("%02x", b));
            return VALID_HASHES.contains(hex.toString());
        } catch (Exception e) {
            plugin.getLogger().severe("[DxLifeStealCore] License check error: " + e.getMessage());
            return false;
        }
    }

    private void printInvalidBanner(String reason) {
        plugin.getLogger().severe("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        plugin.getLogger().severe("  [DxLifeStealCore] LICENSE INVALID!");
        plugin.getLogger().severe("  Reason: " + reason);
        plugin.getLogger().severe("  Contact: DipuXPro to get a valid key.");
        plugin.getLogger().severe("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    private String maskKey(String key) {
        if (key.length() <= 4) return "****";
        return key.substring(0, 3) + "****" + key.substring(key.length() - 3);
    }

    public String getStatus() { return valid ? "VALID ✓" : "INVALID ✗"; }
    public boolean isValid() { return valid; }
}
