package dev.dxlifesteal.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ColorUtil {

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final Pattern HEX_PATTERN = Pattern.compile("<#([A-Fa-f0-9]{6})>");
    private static final Pattern HEX_PATTERN_2 = Pattern.compile("&#([A-Fa-f0-9]{6})");

    /**
     * Parse MiniMessage format with hex and gradient support
     */
    public static Component parse(String message) {
        if (message == null) return Component.empty();
        return MINI_MESSAGE.deserialize(message);
    }

    /**
     * Parse with placeholders replaced
     */
    public static Component parse(String message, String... replacements) {
        if (message == null) return Component.empty();
        for (int i = 0; i < replacements.length - 1; i += 2) {
            message = message.replace(replacements[i], replacements[i + 1]);
        }
        return MINI_MESSAGE.deserialize(message);
    }

    /**
     * Convert MiniMessage to legacy string (for older APIs)
     */
    public static String toLegacy(String message) {
        if (message == null) return "";
        Component component = MINI_MESSAGE.deserialize(message);
        return LegacyComponentSerializer.legacySection().serialize(component);
    }

    /**
     * Parse legacy color codes (&a, &b, etc.) + hex support
     */
    public static String colorize(String message) {
        if (message == null) return "";

        // Handle &#RRGGBB format
        Matcher matcher = HEX_PATTERN_2.matcher(message);
        StringBuffer buffer = new StringBuffer();
        while (matcher.find()) {
            String hex = matcher.group(1);
            matcher.appendReplacement(buffer, net.md_5.bungee.api.ChatColor.of("#" + hex).toString());
        }
        matcher.appendTail(buffer);
        message = buffer.toString();

        return ChatColor.translateAlternateColorCodes('&', message);
    }

    /**
     * Strip all color codes
     */
    public static String strip(String message) {
        if (message == null) return "";
        return MINI_MESSAGE.stripTags(message);
    }

    /**
     * Parse a list of strings
     */
    public static List<Component> parseList(List<String> messages) {
        return messages.stream().map(ColorUtil::parse).collect(Collectors.toList());
    }

    /**
     * Replace placeholders in message
     */
    public static String replacePlaceholders(String message, String... replacements) {
        if (message == null) return "";
        for (int i = 0; i < replacements.length - 1; i += 2) {
            if (replacements[i] != null && replacements[i + 1] != null) {
                message = message.replace(replacements[i], replacements[i + 1]);
            }
        }
        return message;
    }
}
