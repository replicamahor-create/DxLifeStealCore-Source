package dev.dxlifesteal.database;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class DatabaseManager {

    private final DxLifeStealCore plugin;
    private File dataFolder;

    // In-memory cache of all player YML files
    private final Map<UUID, File> playerFiles = new HashMap<>();
    private final Map<UUID, FileConfiguration> playerConfigs = new HashMap<>();

    // History stored per player yml
    // Dirty flag - which players need saving
    private final Set<UUID> dirty = new HashSet<>();

    public DatabaseManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public boolean initialize() {
        String folderName = plugin.getConfig().getString("storage.data-folder", "playerdata");
        dataFolder = new File(plugin.getDataFolder(), folderName);
        if (!dataFolder.exists()) dataFolder.mkdirs();
        plugin.getLogger().info("[DxLifeStealCore] Storage system initialized (YML) ✓");
        return true;
    }

    // -------------------------------------------------------
    //   LOAD PLAYER
    // -------------------------------------------------------

    public FileConfiguration loadPlayer(UUID uuid) {
        if (playerConfigs.containsKey(uuid)) {
            return playerConfigs.get(uuid);
        }

        File file = new File(dataFolder, uuid.toString() + ".yml");
        playerFiles.put(uuid, file);

        FileConfiguration cfg;
        if (file.exists()) {
            cfg = YamlConfiguration.loadConfiguration(file);
        } else {
            cfg = new YamlConfiguration();
            // Set defaults
            int startHearts = plugin.getConfigManager().getStartingHearts();
            int maxHearts = plugin.getConfigManager().getMaxHearts();
            cfg.set("hearts", startHearts);
            cfg.set("max-hearts", maxHearts);
            cfg.set("kills", 0);
            cfg.set("deaths", 0);
            cfg.set("eliminations", 0);
            cfg.set("streak", 0);
            cfg.set("best-streak", 0);
            cfg.set("eliminated", false);
            cfg.set("frozen", false);
            cfg.set("bypassed", false);
            cfg.set("history", new ArrayList<>());
        }

        playerConfigs.put(uuid, cfg);
        return cfg;
    }

    // -------------------------------------------------------
    //   SAVE PLAYER (immediate)
    // -------------------------------------------------------

    public void savePlayer(UUID uuid) {
        FileConfiguration cfg = playerConfigs.get(uuid);
        File file = playerFiles.get(uuid);
        if (cfg == null || file == null) return;

        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("[DxLifeStealCore] Failed to save player " + uuid + ": " + e.getMessage());
        }
    }

    // -------------------------------------------------------
    //   MARK DIRTY (needs saving next tick)
    // -------------------------------------------------------

    public void markDirty(UUID uuid) {
        dirty.add(uuid);
    }

    // -------------------------------------------------------
    //   SAVE ALL DIRTY (called every second)
    // -------------------------------------------------------

    public void saveDirty() {
        if (dirty.isEmpty()) return;
        Set<UUID> toSave = new HashSet<>(dirty);
        dirty.clear();
        for (UUID uuid : toSave) {
            savePlayer(uuid);
        }
    }

    // -------------------------------------------------------
    //   SAVE ALL
    // -------------------------------------------------------

    public void saveAll() {
        long start = System.currentTimeMillis();
        for (UUID uuid : new HashSet<>(playerConfigs.keySet())) {
            savePlayer(uuid);
        }
        long ms = System.currentTimeMillis() - start;
        plugin.getLogger().info("[Scheduled Save] Saved data to file... " + ms + "ms");
    }

    // -------------------------------------------------------
    //   UNLOAD PLAYER
    // -------------------------------------------------------

    public void unloadPlayer(UUID uuid) {
        savePlayer(uuid);
        playerFiles.remove(uuid);
        playerConfigs.remove(uuid);
        dirty.remove(uuid);
    }

    // -------------------------------------------------------
    //   LOG HISTORY
    // -------------------------------------------------------

    public void logHistory(UUID uuid, String type, int amount, UUID relatedPlayer) {
        FileConfiguration cfg = playerConfigs.get(uuid);
        if (cfg == null) return;

        List<String> history = cfg.getStringList("history");
        String entry = System.currentTimeMillis() + "|" + type + "|" + amount + "|" +
            (relatedPlayer != null ? relatedPlayer.toString() : "none");

        history.add(0, entry); // newest first

        // Keep last 50 entries
        if (history.size() > 50) {
            history = history.subList(0, 50);
        }

        cfg.set("history", history);
        markDirty(uuid);
    }

    // -------------------------------------------------------
    //   GET TOP PLAYERS (scan all yml files)
    // -------------------------------------------------------

    public List<String[]> getTopPlayers(String field, int limit) {
        List<String[]> results = new ArrayList<>();

        // Scan all yml files in data folder
        File[] files = dataFolder.listFiles((dir, name) -> name.endsWith(".yml"));
        if (files == null) return results;

        for (File file : files) {
            try {
                FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
                if (cfg.getBoolean("eliminated", false)) continue;

                String name = cfg.getString("name", file.getName().replace(".yml", ""));
                int value;
                switch (field) {
                    case "kills": value = cfg.getInt("kills", 0); break;
                    case "deaths": value = cfg.getInt("deaths", 0); break;
                    case "eliminations": value = cfg.getInt("eliminations", 0); break;
                    default: value = cfg.getInt("hearts", 0); break;
                }
                results.add(new String[]{name, String.valueOf(value)});
            } catch (Exception ignored) {}
        }

        // Sort descending
        results.sort((a, b) -> Integer.compare(
            Integer.parseInt(b[1]), Integer.parseInt(a[1])
        ));

        // Limit
        if (results.size() > limit) {
            results = results.subList(0, limit);
        }

        return results;
    }

    // -------------------------------------------------------
    //   GET PLAYER HISTORY
    // -------------------------------------------------------

    public List<String> getPlayerHistory(UUID uuid, int limit) {
        FileConfiguration cfg = playerConfigs.get(uuid);
        if (cfg == null) {
            // Load from file if not in cache
            File file = new File(dataFolder, uuid.toString() + ".yml");
            if (!file.exists()) return new ArrayList<>();
            cfg = YamlConfiguration.loadConfiguration(file);
        }
        List<String> history = cfg.getStringList("history");
        if (history.size() > limit) {
            return history.subList(0, limit);
        }
        return history;
    }

    // -------------------------------------------------------
    //   GETTERS
    // -------------------------------------------------------

    public FileConfiguration getPlayerConfig(UUID uuid) {
        return playerConfigs.get(uuid);
    }

    public boolean isPlayerLoaded(UUID uuid) {
        return playerConfigs.containsKey(uuid);
    }

    public void close() {
        saveAll();
        playerConfigs.clear();
        playerFiles.clear();
        dirty.clear();
    }

    // Legacy method stubs for compatibility
    public boolean isMySQL() { return false; }
}
