package dev.dxlifesteal.placeholders;

import dev.dxlifesteal.DxLifeStealCore;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class DxPlaceholderAPI extends PlaceholderExpansion {

    private final DxLifeStealCore plugin;

    public DxPlaceholderAPI(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() { return "dxls"; }

    @Override
    public @NotNull String getAuthor() { return "DipuXPro"; }

    @Override
    public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }

    @Override
    public boolean persist() { return true; }

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";

        var hm = plugin.getHeartManager();
        var uuid = player.getUniqueId();

        switch (params.toLowerCase()) {
            case "hearts":
                return String.valueOf(hm.getHearts(uuid));
            case "max_hearts":
                return String.valueOf(hm.getMaxHearts(uuid));
            case "kills":
                return String.valueOf(hm.getKills(uuid));
            case "deaths":
                return String.valueOf(hm.getDeaths(uuid));
            case "eliminations":
                return String.valueOf(hm.getEliminations(uuid));
            case "streak":
                return String.valueOf(plugin.getStreakManager().getStreak(uuid));
            case "best_streak":
                return String.valueOf(plugin.getStreakManager().getBestStreak(uuid));
            case "status":
                if (hm.isEliminated(uuid)) return "Eliminated";
                if (hm.isFrozen(uuid)) return "Frozen";
                if (hm.isBypassed(uuid)) return "Bypassed";
                return "Active";
            case "is_eliminated":
                return String.valueOf(hm.isEliminated(uuid));
            case "is_frozen":
                return String.valueOf(hm.isFrozen(uuid));
            case "is_bypassed":
                return String.valueOf(hm.isBypassed(uuid));
            case "event_double":
                return String.valueOf(plugin.getEventManager().isDoubleHeartsActive());
            case "event_rain":
                return String.valueOf(plugin.getEventManager().isHeartRainActive());
            default:
                return null;
        }
    }
}
