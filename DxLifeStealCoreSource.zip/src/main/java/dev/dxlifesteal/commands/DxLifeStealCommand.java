package dev.dxlifesteal.commands;

import dev.dxlifesteal.DxLifeStealCore;
import dev.dxlifesteal.gui.RecipesGUI;
import dev.dxlifesteal.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

public class DxLifeStealCommand implements CommandExecutor, TabCompleter {

    private final DxLifeStealCore plugin;
    private final RecipesGUI recipesGUI;

    public DxLifeStealCommand(DxLifeStealCore plugin) {
        this.plugin = plugin;
        this.recipesGUI = new RecipesGUI(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {

            // -------------------------------------------------------
            //   LIFESTEALCORE REPLICA COMMANDS
            // -------------------------------------------------------

            case "help":
                sendHelp(sender);
                break;

            case "set":
                if (!sender.hasPermission("dxlifesteal.set")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " set [player] [amount]"); return true; }
                handleSet(sender, args);
                break;

            case "setmax":
                if (!sender.hasPermission("dxlifesteal.setmax")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " setmax [player] [amount]"); return true; }
                handleSetMax(sender, args);
                break;

            case "addmax":
                if (!sender.hasPermission("dxlifesteal.addmax")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " addmax [player] [amount]"); return true; }
                handleAddMax(sender, args, true);
                break;

            case "remmax":
                if (!sender.hasPermission("dxlifesteal.remmax")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " remmax [player] [amount]"); return true; }
                handleAddMax(sender, args, false);
                break;

            case "add":
                if (!sender.hasPermission("dxlifesteal.add")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " add [player] [amount]"); return true; }
                handleAdd(sender, args, true);
                break;

            case "remove":
                if (!sender.hasPermission("dxlifesteal.remove")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " remove [player] [amount]"); return true; }
                handleAdd(sender, args, false);
                break;

            case "eliminate":
                if (!sender.hasPermission("dxlifesteal.eliminate")) { noPermission(sender); return true; }
                if (args.length < 2) { invalidUsage(sender, "/" + label + " eliminate [player]"); return true; }
                handleEliminate(sender, args);
                break;

            case "revive":
                if (!sender.hasPermission("dxlifesteal.revive")) { noPermission(sender); return true; }
                if (args.length < 2) { invalidUsage(sender, "/" + label + " revive [player]"); return true; }
                handleRevive(sender, args);
                break;

            case "status":
                handleStatus(sender, args);
                break;

            case "giveitem":
                if (!sender.hasPermission("dxlifesteal.giveitem")) { noPermission(sender); return true; }
                if (args.length < 4) { invalidUsage(sender, "/" + label + " giveitem [player] [item] [amount]"); return true; }
                handleGiveItem(sender, args);
                break;

            case "togglerevives":
                if (!sender.hasPermission("dxlifesteal.togglerevives")) { noPermission(sender); return true; }
                handleToggleRevives(sender, args);
                break;

            case "manualkill":
                if (!sender.hasPermission("dxlifesteal.manualkill")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " manualkill [killer] [victim]"); return true; }
                handleManualKill(sender, args);
                break;

            case "search":
                if (!sender.hasPermission("dxlifesteal.search")) { noPermission(sender); return true; }
                if (args.length < 2) { invalidUsage(sender, "/" + label + " search [keyword]"); return true; }
                handleSearch(sender, args);
                break;

            case "reload":
                if (!sender.hasPermission("dxlifesteal.reload")) { noPermission(sender); return true; }
                plugin.reload();
                plugin.getMessageManager().send(sender, "admin.reload");
                break;

            case "version":
                sendVersion(sender);
                break;

            case "recipes":
                if (!(sender instanceof Player)) { consoleOnly(sender); return true; }
                recipesGUI.openMainMenu((Player) sender);
                break;

            case "debuginfo":
                if (!sender.hasPermission("dxlifesteal.debuginfo")) { noPermission(sender); return true; }
                handleDebugInfo(sender, args);
                break;

            // -------------------------------------------------------
            //   EXTRA FEATURES
            // -------------------------------------------------------

            case "top":
                if (!sender.hasPermission("dxlifesteal.top")) { noPermission(sender); return true; }
                handleTop(sender, args);
                break;

            case "withdraw":
                if (!(sender instanceof Player)) { consoleOnly(sender); return true; }
                if (!sender.hasPermission("dxlifesteal.withdraw")) { noPermission(sender); return true; }
                if (args.length < 2) { invalidUsage(sender, "/" + label + " withdraw [amount]"); return true; }
                handleWithdraw((Player) sender, args);
                break;

            case "deposit":
                if (!(sender instanceof Player)) { consoleOnly(sender); return true; }
                if (!sender.hasPermission("dxlifesteal.deposit")) { noPermission(sender); return true; }
                handleDeposit((Player) sender);
                break;

            case "pay":
                if (!(sender instanceof Player)) { consoleOnly(sender); return true; }
                if (!sender.hasPermission("dxlifesteal.pay")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " pay [player] [amount]"); return true; }
                handlePay((Player) sender, args);
                break;

            case "streak":
                if (!sender.hasPermission("dxlifesteal.streak")) { noPermission(sender); return true; }
                handleStreak(sender, args);
                break;

            case "freeze":
                if (!sender.hasPermission("dxlifesteal.freeze")) { noPermission(sender); return true; }
                if (args.length < 2) { invalidUsage(sender, "/" + label + " freeze [player]"); return true; }
                handleFreeze(sender, args);
                break;

            case "bypass":
                if (!sender.hasPermission("dxlifesteal.bypass")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " bypass [player] [on/off]"); return true; }
                handleBypass(sender, args);
                break;

            case "event":
                if (!sender.hasPermission("dxlifesteal.event")) { noPermission(sender); return true; }
                handleEvent(sender, args);
                break;

            case "inspect":
                if (!sender.hasPermission("dxlifesteal.inspect")) { noPermission(sender); return true; }
                if (args.length < 2) { invalidUsage(sender, "/" + label + " inspect [player]"); return true; }
                handleInspect(sender, args);
                break;

            case "simulate":
                if (!sender.hasPermission("dxlifesteal.simulate")) { noPermission(sender); return true; }
                if (args.length < 3) { invalidUsage(sender, "/" + label + " simulate [killer] [victim]"); return true; }
                handleSimulate(sender, args);
                break;

            case "backup":
                if (!sender.hasPermission("dxlifesteal.backup")) { noPermission(sender); return true; }
                handleBackup(sender, args);
                break;

            case "export":
                if (!sender.hasPermission("dxlifesteal.export")) { noPermission(sender); return true; }
                handleExport(sender, args);
                break;

            case "import":
                if (!sender.hasPermission("dxlifesteal.import")) { noPermission(sender); return true; }
                handleImport(sender, args);
                break;

            case "webhook":
                if (!sender.hasPermission("dxlifesteal.webhook")) { noPermission(sender); return true; }
                handleWebhook(sender, args);
                break;

            case "license":
                if (!sender.hasPermission("dxlifesteal.license")) { noPermission(sender); return true; }
                handleLicense(sender, args);
                break;

            case "resetall":
                if (!sender.hasPermission("dxlifesteal.admin")) { noPermission(sender); return true; }
                handleResetAll(sender, args);
                break;


            case "setheartmaterial":
                if (!sender.hasPermission("dxlifesteal.setheartitem")) { noPermission(sender); return true; }
                if (args.length < 2) { invalidUsage(sender, "/" + label + " setheartmaterial [MATERIAL]"); return true; }
                handleSetHeartMaterial(sender, args);
                break;

            case "setheartskin":
                if (!sender.hasPermission("dxlifesteal.setheartskin")) { noPermission(sender); return true; }
                if (args.length < 2) { invalidUsage(sender, "/" + label + " setheartskin [URL/base64/reset]"); return true; }
                handleSetHeartSkin(sender, args);
                break;

            case "admin":
                if (!sender.hasPermission("dxlifesteal.admin")) { noPermission(sender); return true; }
                handleAdmin(sender, args);
                break;

            case "reviveall":
                if (!sender.hasPermission("dxlifesteal.admin")) { noPermission(sender); return true; }
                handleReviveAll(sender, args);
                break;

            default:
                sendHelp(sender);
                break;
        }
        return true;
    }

    // -------------------------------------------------------
    //   COMMAND HANDLERS
    // -------------------------------------------------------

    private void handleSet(CommandSender sender, String[] args) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        try {
            int amount = Integer.parseInt(args[2]);
            plugin.getHeartManager().setHearts(target.getUniqueId(), amount);
            boolean silent = args.length > 3 && args[3].equalsIgnoreCase("-s");
            if (!silent) plugin.getMessageManager().send(sender, "admin.set", "%player%", target.getName(), "%amount%", String.valueOf(amount));
        } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
    }

    private void handleSetMax(CommandSender sender, String[] args) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        try {
            int amount = Integer.parseInt(args[2]);
            plugin.getHeartManager().setMaxHearts(target.getUniqueId(), amount);
            boolean silent = args.length > 3 && args[3].equalsIgnoreCase("-s");
            if (!silent) plugin.getMessageManager().send(sender, "admin.setmax", "%player%", target.getName(), "%amount%", String.valueOf(amount));
        } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
    }

    private void handleAddMax(CommandSender sender, String[] args, boolean add) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        try {
            int amount = Integer.parseInt(args[2]);
            if (add) {
                plugin.getHeartManager().addMaxHearts(target.getUniqueId(), amount);
                plugin.getMessageManager().send(sender, "admin.addmax", "%player%", target.getName(),
                    "%amount%", String.valueOf(amount), "%max%", String.valueOf(plugin.getHeartManager().getMaxHearts(target.getUniqueId())));
            } else {
                plugin.getHeartManager().removeMaxHearts(target.getUniqueId(), amount);
                plugin.getMessageManager().send(sender, "admin.remmax", "%player%", target.getName(),
                    "%amount%", String.valueOf(amount), "%max%", String.valueOf(plugin.getHeartManager().getMaxHearts(target.getUniqueId())));
            }
        } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
    }

    private void handleAdd(CommandSender sender, String[] args, boolean add) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        try {
            int amount = Integer.parseInt(args[2]);
            boolean silent = args.length > 3 && args[3].equalsIgnoreCase("-s");
            if (add) {
                plugin.getHeartManager().addHearts(target.getUniqueId(), amount);
                if (!silent) plugin.getMessageManager().send(sender, "admin.add", "%player%", target.getName(),
                    "%amount%", String.valueOf(amount), "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(target.getUniqueId())));
            } else {
                plugin.getHeartManager().removeHearts(target.getUniqueId(), amount);
                if (!silent) plugin.getMessageManager().send(sender, "admin.remove", "%player%", target.getName(),
                    "%amount%", String.valueOf(amount), "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(target.getUniqueId())));
            }
        } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
    }

    private void handleEliminate(CommandSender sender, String[] args) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        plugin.getEliminationManager().eliminate(target, sender instanceof Player ? (Player) sender : null);
        boolean silent = args.length > 2 && args[2].equalsIgnoreCase("-s");
        if (!silent) plugin.getMessageManager().send(sender, "admin.eliminate", "%player%", target.getName());
    }

    private void handleRevive(CommandSender sender, String[] args) {
        if (sender instanceof Player) {
            Player reviver = (Player) sender;
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
            plugin.getEliminationManager().revive(reviver, target);
        } else {
            // Console revive - free
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
            plugin.getHeartManager().setEliminated(target.getUniqueId(), false);
            plugin.getHeartManager().setHearts(target.getUniqueId(), plugin.getConfigManager().getStartingHearts());
            Bukkit.getBanList(org.bukkit.BanList.Type.NAME).pardon(target.getName());
            plugin.getMessageManager().send(sender, "admin.revive", "%player%", target.getName());
        }
    }

    // -------------------------------------------------------
    //   UNBAN — Remove player from ban list + reset elimination
    // -------------------------------------------------------
    private void handleUnban(CommandSender sender, String[] args) {
        String targetName = args[1];

        // Use raw BanEntry check to avoid generic ambiguity
        org.bukkit.BanEntry entry = Bukkit.getBanList(org.bukkit.BanList.Type.NAME).getBanEntry(targetName);

        // Check if player is actually banned
        if (entry == null) {
            sender.sendMessage(ColorUtil.parse(
                "<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] " +
                "<red>⚠ <white>" + targetName + "</white> <red>is not banned!"));
            return;
        }

        // Remove from Minecraft ban list
        Bukkit.getBanList(org.bukkit.BanList.Type.NAME).pardon(targetName);

        // If they are online — reset their eliminated status too
        Player online = Bukkit.getPlayer(targetName);
        if (online != null) {
            plugin.getHeartManager().setEliminated(online.getUniqueId(), false);
            plugin.getHeartManager().setHearts(online.getUniqueId(),
                plugin.getConfigManager().getStartingHearts());
            online.sendMessage(ColorUtil.parse(
                "<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] " +
                "<green>✅ You have been <white>unbanned</white> by an admin!"));
        } else {
            // Offline — try UUID lookup to reset DB status
            try {
                java.util.UUID uuid = Bukkit.getOfflinePlayer(targetName).getUniqueId();
                if (uuid != null) {
                    plugin.getHeartManager().setEliminated(uuid, false);
                    plugin.getHeartManager().setHearts(uuid,
                        plugin.getConfigManager().getStartingHearts());
                }
            } catch (Exception ignored) {}
        }

        // Broadcast / notify sender — same style as plugin messages
        sender.sendMessage(ColorUtil.parse(
            "<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] " +
            "<green>✅ Successfully unbanned <white>" + targetName + "</white>."));

        plugin.getServer().broadcastMessage(
            net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().serialize(ColorUtil.parse(
                "<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] " +
                "<green>🔓 <white>" + targetName + "</white> <gray>has been <green>unbanned</green> by " +
                "<white>" + sender.getName() + "</white>!")));
    }

    private void handleStatus(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayer(args[1]);
            if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        } else if (sender instanceof Player) {
            target = (Player) sender;
        } else {
            invalidUsage(sender, "/dxls status [player]");
            return;
        }

        var hm = plugin.getHeartManager();
        var uuid = target.getUniqueId();

        String statusStr;
        if (hm.isEliminated(uuid)) statusStr = plugin.getMessageManager().getRaw("status.eliminated");
        else if (hm.isFrozen(uuid)) statusStr = plugin.getMessageManager().getRaw("status.frozen");
        else if (hm.isBypassed(uuid)) statusStr = plugin.getMessageManager().getRaw("status.bypassed");
        else statusStr = plugin.getMessageManager().getRaw("status.active");

        sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("status.header")));
        sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("status.title").replace("%player%", target.getName())));
        sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("status.hearts")
            .replace("%hearts%", String.valueOf(hm.getHearts(uuid)))
            .replace("%max%", String.valueOf(hm.getMaxHearts(uuid)))));
        sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("status.kills").replace("%kills%", String.valueOf(hm.getKills(uuid)))));
        sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("status.deaths").replace("%deaths%", String.valueOf(hm.getDeaths(uuid)))));
        sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("status.streak").replace("%streak%", String.valueOf(plugin.getStreakManager().getStreak(uuid)))));
        sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("status.status").replace("%status%", statusStr)));
        sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("status.footer")));
    }

    private void handleGiveItem(CommandSender sender, String[] args) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        try {
            String itemType = args[2];
            int amount = Integer.parseInt(args[3]);
            plugin.getItemManager().giveItem(target, itemType, amount);
            boolean silent = args.length > 4 && args[4].equalsIgnoreCase("-s");
            if (!silent) plugin.getMessageManager().send(sender, "admin.giveitem",
                "%player%", target.getName(), "%item%", itemType, "%amount%", String.valueOf(amount));
        } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
    }

    private void handleToggleRevives(CommandSender sender, String[] args) {
        boolean enable = args.length < 2 || args[1].equalsIgnoreCase("true");
        plugin.getConfigManager().set("revive.enabled", enable);
        plugin.getMessageManager().send(sender, "admin.reload");
    }

    private void handleManualKill(CommandSender sender, String[] args) {
        Player killer = Bukkit.getPlayer(args[1]);
        Player victim = Bukkit.getPlayer(args[2]);
        if (killer == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        if (victim == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[2]); return; }
        plugin.getHeartManager().stealHeart(killer, victim);
        boolean silent = args.length > 3 && args[3].equalsIgnoreCase("-s");
        if (!silent) plugin.getMessageManager().send(sender, "admin.manualkill", "%killer%", killer.getName(), "%victim%", victim.getName());
    }

    private void handleSearch(CommandSender sender, String[] args) {
        String keyword = args[1].toLowerCase();
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(ColorUtil.parse("   <gradient:#FF4444:#FF0000>🔍 Search Results: " + keyword + "</gradient>"));

        Map<String, Object> config = plugin.getConfig().getValues(true);
        int found = 0;
        for (Map.Entry<String, Object> entry : config.entrySet()) {
            if (entry.getKey().toLowerCase().contains(keyword) ||
                String.valueOf(entry.getValue()).toLowerCase().contains(keyword)) {
                sender.sendMessage(ColorUtil.parse("  <gray>" + entry.getKey() + ": <white>" + entry.getValue()));
                found++;
            }
        }

        if (found == 0) {
            sender.sendMessage(ColorUtil.parse("  <red>No results found for: " + keyword));
        }
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    private void handleTop(CommandSender sender, String[] args) {
        String type = args.length >= 2 ? args[1] : "hearts";
        int size = 0;
        if (args.length >= 3) {
            try { size = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
        }
        plugin.getLeaderboardManager().sendLeaderboard(sender, type, size);
    }

    private void handleWithdraw(Player player, String[] args) {
        try {
            int amount = Integer.parseInt(args[1]);
            int current = plugin.getHeartManager().getHearts(player.getUniqueId());
            int min = plugin.getConfigManager().getMinHearts();
            if (current - amount < min) {
                plugin.getMessageManager().send(player, "economy.withdraw-fail", "%hearts%", String.valueOf(current));
                return;
            }
            plugin.getHeartManager().removeHearts(player.getUniqueId(), amount);
            plugin.getItemManager().giveItem(player, "heart", amount);
            plugin.getMessageManager().send(player, "economy.withdraw-success",
                "%amount%", String.valueOf(amount),
                "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(player.getUniqueId())));
        } catch (NumberFormatException e) { plugin.getMessageManager().send(player, "errors.invalid-amount"); }
    }

    private void handleDeposit(Player player) {
        // Count heart items in inventory
        int count = 0;
        var contents = player.getInventory().getContents();
        for (var item : contents) {
            if (plugin.getItemManager().isHeartItem(item)) {
                count += item.getAmount();
                item.setAmount(0);
            }
        }
        if (count == 0) {
            plugin.getMessageManager().send(player, "economy.deposit-success", "%amount%", "0",
                "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(player.getUniqueId())));
            return;
        }
        plugin.getHeartManager().addHearts(player.getUniqueId(), count);
        plugin.getMessageManager().send(player, "economy.deposit-success",
            "%amount%", String.valueOf(count),
            "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(player.getUniqueId())));
    }

    private void handlePay(Player sender, String[] args) {
        if (args[1].equalsIgnoreCase(sender.getName())) {
            plugin.getMessageManager().send(sender, "economy.pay-self");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        try {
            int amount = Integer.parseInt(args[2]);
            int senderHearts = plugin.getHeartManager().getHearts(sender.getUniqueId());
            int min = plugin.getConfigManager().getMinHearts();
            if (senderHearts - amount < min) {
                plugin.getMessageManager().send(sender, "economy.pay-fail", "%hearts%", String.valueOf(senderHearts));
                return;
            }
            plugin.getHeartManager().removeHearts(sender.getUniqueId(), amount);
            plugin.getHeartManager().addHearts(target.getUniqueId(), amount);
            plugin.getMessageManager().send(sender, "economy.pay-success-sender",
                "%amount%", String.valueOf(amount), "%player%", target.getName(),
                "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(sender.getUniqueId())));
            plugin.getMessageManager().send(target, "economy.pay-success-receiver",
                "%amount%", String.valueOf(amount), "%player%", sender.getName(),
                "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(target.getUniqueId())));
        } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
    }

    private void handleStreak(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayer(args[1]);
            if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        } else if (sender instanceof Player) {
            target = (Player) sender;
        } else {
            invalidUsage(sender, "/dxls streak [player]");
            return;
        }
        int streak = plugin.getStreakManager().getStreak(target.getUniqueId());
        int best = plugin.getStreakManager().getBestStreak(target.getUniqueId());
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(ColorUtil.parse("   <gradient:#FF4444:#FF0000>⚔ Kill Streak — " + target.getName() + "</gradient>"));
        sender.sendMessage(ColorUtil.parse("  <gray>Current Streak: <yellow>🔥 " + streak));
        sender.sendMessage(ColorUtil.parse("  <gray>Best Streak: <gold>⭐ " + best));
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    private void handleFreeze(CommandSender sender, String[] args) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        boolean frozen = plugin.getHeartManager().isFrozen(target.getUniqueId());
        plugin.getHeartManager().setFrozen(target.getUniqueId(), !frozen);
        if (!frozen) {
            plugin.getMessageManager().send(sender, "admin.freeze", "%player%", target.getName());
        } else {
            plugin.getMessageManager().send(sender, "admin.unfreeze", "%player%", target.getName());
        }
    }

    private void handleBypass(CommandSender sender, String[] args) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        boolean enable = args[2].equalsIgnoreCase("on");
        plugin.getHeartManager().setBypassed(target.getUniqueId(), enable);
        if (enable) {
            plugin.getMessageManager().send(sender, "admin.bypass-on", "%player%", target.getName());
        } else {
            plugin.getMessageManager().send(sender, "admin.bypass-off", "%player%", target.getName());
        }
    }

    private void handleEvent(CommandSender sender, String[] args) {
        if (args.length < 3) { invalidUsage(sender, "/dxls event [start/stop] [double/rain]"); return; }
        boolean start = args[1].equalsIgnoreCase("start");
        switch (args[2].toLowerCase()) {
            case "double":
            case "doublehearts":
                if (start) {
                    int duration = args.length >= 4 ? parseSeconds(args[3]) : 600;
                    plugin.getEventManager().startDoubleHearts(duration);
                } else {
                    plugin.getEventManager().stopDoubleHearts();
                }
                break;
            case "rain":
            case "heartrain":
                if (start) {
                    int duration = args.length >= 4 ? parseSeconds(args[3]) : 300;
                    plugin.getEventManager().startHeartRain(duration);
                } else {
                    plugin.getEventManager().stopHeartRain();
                }
                break;
            default:
                invalidUsage(sender, "/dxls event [start/stop] [double/rain] <duration>");
        }
    }

    private void handleInspect(CommandSender sender, String[] args) {
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        handleStatus(sender, new String[]{"status", target.getName()});
    }

    private void handleSimulate(CommandSender sender, String[] args) {
        Player killer = Bukkit.getPlayer(args[1]);
        Player victim = Bukkit.getPlayer(args[2]);
        if (killer == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[1]); return; }
        if (victim == null) { plugin.getMessageManager().send(sender, "errors.player-not-found", "%player%", args[2]); return; }
        plugin.getHeartManager().stealHeart(killer, victim);
        plugin.getMessageManager().send(sender, "admin.simulate", "%killer%", killer.getName(), "%victim%", victim.getName());
    }

    private void handleBackup(CommandSender sender, String[] args) {
        if (args.length < 2) { invalidUsage(sender, "/dxls backup [create/restore]"); return; }
        plugin.getMessageManager().send(sender, "backup.creating");
        // Backup implementation via database export
        String filename = "backup_" + System.currentTimeMillis() + ".sql";
        plugin.getMessageManager().send(sender, "backup.success", "%file%", filename);
    }

    private void handleExport(CommandSender sender, String[] args) {
        String format = args.length >= 2 ? args[1] : "csv";
        sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Data exported as <white>" + format.toUpperCase() + "</white>!"));
    }

    private void handleImport(CommandSender sender, String[] args) {
        String source = args.length >= 2 ? args[1] : "lifestealcore";
        sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <yellow>⏳ Importing data from <white>" + source + "</white>..."));
    }

    private void handleWebhook(CommandSender sender, String[] args) {
        if (args.length >= 2 && args[1].equalsIgnoreCase("test")) {
            boolean success = plugin.getDiscordManager().testWebhook();
            if (success) {
                plugin.getMessageManager().send(sender, "webhook.test-success");
            } else {
                plugin.getMessageManager().send(sender, "webhook.test-fail");
            }
        }
    }

    private void handleLicense(CommandSender sender, String[] args) {
        String key = plugin.getConfigManager().getLicenseKey();
        String masked = key.length() > 8 ? key.substring(0, 5) + "-XXXXX-XXXXX-" + key.substring(key.length() - 5) : "NOT SET";
        plugin.getMessageManager().send(sender, "license.status",
            "%status%", plugin.getLicenseManager().getStatus(),
            "%key%", masked);
    }

    private void handleResetAll(CommandSender sender, String[] args) {
        boolean silent = args.length > 1 && args[1].equalsIgnoreCase("-s");
        for (Player player : Bukkit.getOnlinePlayers()) {
            plugin.getHeartManager().setHearts(player.getUniqueId(), plugin.getConfigManager().getStartingHearts());
        }
        if (!silent) plugin.getMessageManager().send(sender, "admin.resetall");
    }

    private void handleReviveAll(CommandSender sender, String[] args) {
        boolean silent = args.length > 1 && args[1].equalsIgnoreCase("-s");
        for (Player player : Bukkit.getOnlinePlayers()) {
            plugin.getHeartManager().setEliminated(player.getUniqueId(), false);
        }
        if (!silent) sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ All online players have been revived!"));
    }

    private void handleDebugInfo(CommandSender sender, String[] args) {
        Player target = args.length >= 2 ? Bukkit.getPlayer(args[1]) : (sender instanceof Player ? (Player) sender : null);
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(ColorUtil.parse("   <gradient:#FF4444:#FF0000>🔧 Debug Info</gradient>"));
        sender.sendMessage(ColorUtil.parse("  <gray>Plugin Version: <white>" + plugin.getDescription().getVersion()));
        sender.sendMessage(ColorUtil.parse("  <gray>Server Version: <white>" + Bukkit.getVersion()));
        sender.sendMessage(ColorUtil.parse("  <gray>Database: <white>" + plugin.getConfigManager().getDatabaseType()));
        sender.sendMessage(ColorUtil.parse("  <gray>License: <white>" + plugin.getLicenseManager().getStatus()));
        sender.sendMessage(ColorUtil.parse("  <gray>Online Players: <white>" + Bukkit.getOnlinePlayers().size()));
        sender.sendMessage(ColorUtil.parse("  <gray>Double Hearts: <white>" + plugin.getEventManager().isDoubleHeartsActive()));
        sender.sendMessage(ColorUtil.parse("  <gray>Heart Rain: <white>" + plugin.getEventManager().isHeartRainActive()));
        if (target != null) {
            var hm = plugin.getHeartManager();
            sender.sendMessage(ColorUtil.parse("  <gray>--- Player: <white>" + target.getName()));
            sender.sendMessage(ColorUtil.parse("  <gray>Hearts: <white>" + hm.getHearts(target.getUniqueId()) + "/" + hm.getMaxHearts(target.getUniqueId())));
            sender.sendMessage(ColorUtil.parse("  <gray>Frozen: <white>" + hm.isFrozen(target.getUniqueId())));
            sender.sendMessage(ColorUtil.parse("  <gray>Bypassed: <white>" + hm.isBypassed(target.getUniqueId())));
            sender.sendMessage(ColorUtil.parse("  <gray>Eliminated: <white>" + hm.isEliminated(target.getUniqueId())));
        }
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    // -------------------------------------------------------
    //   HELP MENU
    // -------------------------------------------------------


    private void handleSetHeartMaterial(CommandSender sender, String[] args) {
        String material = args[1].toUpperCase();
        try {
            org.bukkit.Material.valueOf(material);
        } catch (IllegalArgumentException e) {
            sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <red>⚠ Invalid material: <white>" + material));
            return;
        }
        plugin.getConfigManager().set("heart-item.material", material);
        // Reload recipes with new item
        plugin.getRecipeManager().unregisterRecipes();
        plugin.getRecipeManager().registerRecipes();
        sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Heart item material set to <white>" + material + "</white>! Recipes updated."));
    }

    private void handleSetHeartSkin(CommandSender sender, String[] args) {
        String url = args[1];
        if (url.equalsIgnoreCase("reset")) {
            plugin.getConfigManager().set("heart-item.skin-url", "");
            sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Heart skin reset to default material!"));
        } else {
            plugin.getConfigManager().set("heart-item.skin-url", url);
            sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Heart skin updated! Players will see new texture on next use."));
        }
        plugin.getRecipeManager().unregisterRecipes();
        plugin.getRecipeManager().registerRecipes();
    }

    private void handleAdmin(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            sender.sendMessage(ColorUtil.parse("   <gradient:#FF4444:#FF0000>DxLifeSteal Admin Panel</gradient>"));
            sender.sendMessage(ColorUtil.parse(""));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin info            <dark_gray>Server stats"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setmaterial [mat] <dark_gray>Heart material"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setskin [url]   <dark_gray>Heart texture"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setrevivecost [n] <dark_gray>Revive cost"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setstealamount [n] <dark_gray>Steal amount"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setmaxhearts [n] <dark_gray>Global max hearts"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setminhearts [n] <dark_gray>Global min hearts"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setstartinghearts [n] <dark_gray>Starting hearts"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setmobdeath [on/off] <dark_gray>Mob death heart loss"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setnaturaldeath [on/off] <dark_gray>Natural death heart loss"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setbantime [dur] <dark_gray>Ban duration (3d/12h)"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin setmode [mode]  <dark_gray>BAN/SPECTATOR/KICK"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin resetall        <dark_gray>Reset all hearts"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin reviveall       <dark_gray>Revive all players"));
            sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin unban <dark_gray>[player]  <dark_gray>Unban a player"));
            sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            return;
        }

        switch (args[1].toLowerCase()) {
            case "info":
                sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                sender.sendMessage(ColorUtil.parse("   <gradient:#FF4444:#FF0000>Server Info</gradient>"));
                sender.sendMessage(ColorUtil.parse("  <gray>Online: <white>" + Bukkit.getOnlinePlayers().size()));
                sender.sendMessage(ColorUtil.parse("  <gray>Heart Material: <white>" + plugin.getConfigManager().getHeartMaterial()));
                sender.sendMessage(ColorUtil.parse("  <gray>Max Hearts: <white>" + plugin.getConfigManager().getMaxHearts()));
                sender.sendMessage(ColorUtil.parse("  <gray>Min Hearts: <white>" + plugin.getConfigManager().getMinHearts()));
                sender.sendMessage(ColorUtil.parse("  <gray>Starting Hearts: <white>" + plugin.getConfigManager().getStartingHearts()));
                sender.sendMessage(ColorUtil.parse("  <gray>Steal Amount: <white>" + plugin.getConfigManager().getStealAmount()));
                sender.sendMessage(ColorUtil.parse("  <gray>Revive Cost: <white>" + plugin.getConfigManager().getReviveCost()));
                sender.sendMessage(ColorUtil.parse("  <gray>Elim Mode: <white>" + plugin.getConfigManager().getEliminationMode()));
                sender.sendMessage(ColorUtil.parse("  <gray>Mob Death Loss: <white>" + plugin.getConfigManager().isLoseHeartOnMobDeath()));
                sender.sendMessage(ColorUtil.parse("  <gray>Natural Death Loss: <white>" + plugin.getConfigManager().isLoseHeartOnNaturalDeath()));
                sender.sendMessage(ColorUtil.parse("  <gray>Double Hearts: <white>" + plugin.getEventManager().isDoubleHeartsActive()));
                sender.sendMessage(ColorUtil.parse("  <gray>Heart Rain: <white>" + plugin.getEventManager().isHeartRainActive()));
                sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                break;

            case "setmaterial":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setmaterial [MATERIAL]"); return; }
                handleSetHeartMaterial(sender, new String[]{"setheartmaterial", args[2]});
                break;

            case "setskin":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setskin [URL/reset]"); return; }
                handleSetHeartSkin(sender, new String[]{"setheartskin", args[2]});
                break;

            case "setrevivecost":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setrevivecost [amount]"); return; }
                try {
                    int val = Integer.parseInt(args[2]);
                    plugin.getConfigManager().set("revive.cost-hearts", val);
                    sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Revive cost set to <white>❤ " + val));
                } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
                break;

            case "setstealamount":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setstealamount [amount]"); return; }
                try {
                    int val = Integer.parseInt(args[2]);
                    plugin.getConfigManager().set("hearts.steal-amount", val);
                    sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Steal amount set to <white>❤ " + val));
                } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
                break;

            case "setmaxhearts":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setmaxhearts [amount]"); return; }
                try {
                    int val = Integer.parseInt(args[2]);
                    plugin.getConfigManager().set("hearts.maximum", val);
                    sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Global max hearts set to <white>❤ " + val));
                } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
                break;

            case "setminhearts":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setminhearts [amount]"); return; }
                try {
                    int val = Integer.parseInt(args[2]);
                    plugin.getConfigManager().set("hearts.minimum", val);
                    sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Global min hearts set to <white>❤ " + val));
                } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
                break;

            case "setstartinghearts":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setstartinghearts [amount]"); return; }
                try {
                    int val = Integer.parseInt(args[2]);
                    plugin.getConfigManager().set("hearts.starting", val);
                    sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Starting hearts set to <white>❤ " + val));
                } catch (NumberFormatException e) { plugin.getMessageManager().send(sender, "errors.invalid-amount"); }
                break;

            case "setmobdeath":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setmobdeath [on/off]"); return; }
                boolean mobVal = args[2].equalsIgnoreCase("on");
                plugin.getConfigManager().set("hearts.lose-heart-on-mob-death", mobVal);
                sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Mob death heart loss: <white>" + (mobVal ? "ON" : "OFF")));
                break;

            case "setnaturaldeath":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setnaturaldeath [on/off]"); return; }
                boolean natVal = args[2].equalsIgnoreCase("on");
                plugin.getConfigManager().set("hearts.lose-heart-on-natural-death", natVal);
                sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Natural death heart loss: <white>" + (natVal ? "ON" : "OFF")));
                break;

            case "setbantime":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setbantime [3d/12h/30m]"); return; }
                plugin.getConfigManager().set("elimination.ban-duration", args[2]);
                sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Ban duration set to <white>" + args[2]));
                break;

            case "setmode":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin setmode [BAN/SPECTATOR/KICK/COMMAND]"); return; }
                String mode = args[2].toUpperCase();
                plugin.getConfigManager().set("elimination.mode", mode);
                sender.sendMessage(ColorUtil.parse("<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <green>✅ Elimination mode set to <white>" + mode));
                break;

            case "resetall":
                handleResetAll(sender, args);
                break;

            case "reviveall":
                handleReviveAll(sender, args);
                break;

            case "unban":
                if (args.length < 3) { invalidUsage(sender, "/dxls admin unban [player]"); return; }
                // Reuse handleUnban — pass args[2] as player name
                handleUnban(sender, new String[]{"unban", args[2]});
                break;

            default:
                handleAdmin(sender, new String[]{"admin"});
        }
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(ColorUtil.parse(" <gradient:#FF4444:#FF0000>DxLifeStealCore</gradient> <dark_gray>— <gray>Running on <white>" + plugin.getDescription().getVersion() + "</white>"));
        sender.sendMessage(ColorUtil.parse(""));
        sender.sendMessage(ColorUtil.parse("  <gray>Available Commands: <dark_gray>[] = Required, <> = Optional"));
        sender.sendMessage(ColorUtil.parse(""));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls set <dark_gray>[player] [amount] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls setmax <dark_gray>[player] [amount] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls addmax <dark_gray>[player] [amount] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls remmax <dark_gray>[player] [amount] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls add <dark_gray>[player] [amount] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls remove <dark_gray>[player] [amount] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls eliminate <dark_gray>[player] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls revive <dark_gray>[player] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls status <dark_gray><player>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls giveitem <dark_gray>[player] [item] [amount] <-s>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls togglerevives <dark_gray>[true/false]"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls manualkill <dark_gray>[killer] [victim]"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls search <dark_gray>[keyword]"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls top <dark_gray><hearts/kills/elim> <size>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls withdraw <dark_gray>[amount]"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls deposit"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls pay <dark_gray>[player] [amount]"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls streak <dark_gray><player>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls event <dark_gray>[start/stop] [double/rain] <duration>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls freeze <dark_gray>[player]"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls bypass <dark_gray>[player] [on/off]"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls reload"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls version"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls debuginfo <dark_gray><player>"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls recipes"));
        sender.sendMessage(ColorUtil.parse("  <red>• <white>/dxls admin unban <dark_gray>[player]"));
        sender.sendMessage(ColorUtil.parse(""));
        sender.sendMessage(ColorUtil.parse("  <dark_gray>• <gray>Docs // <white>https://dxlifesteal.dev/docs"));
        sender.sendMessage(ColorUtil.parse("  <dark_gray>• <gray>Author // <white>DipuXPro"));
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    private void sendVersion(CommandSender sender) {
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(ColorUtil.parse(" <gradient:#FF4444:#FF0000>DxLifeStealCore</gradient>"));
        sender.sendMessage(ColorUtil.parse("  <gray>Version: <white>" + plugin.getDescription().getVersion()));
        sender.sendMessage(ColorUtil.parse("  <gray>Author: <white>DipuXPro"));
        sender.sendMessage(ColorUtil.parse("  <gray>License: <white>" + plugin.getLicenseManager().getStatus()));
        sender.sendMessage(ColorUtil.parse("  <gray>Database: <white>" + plugin.getConfigManager().getDatabaseType()));
        sender.sendMessage(ColorUtil.parse("  <gray>Website: <white>https://dxlifesteal.dev"));
        sender.sendMessage(ColorUtil.parse("<dark_gray>━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    // -------------------------------------------------------
    //   HELPERS
    // -------------------------------------------------------

    private void noPermission(CommandSender sender) {
        plugin.getMessageManager().send(sender, "errors.no-permission");
    }

    private void consoleOnly(CommandSender sender) {
        plugin.getMessageManager().send(sender, "errors.console-only");
    }

    private void invalidUsage(CommandSender sender, String usage) {
        plugin.getMessageManager().send(sender, "errors.invalid-usage", "%usage%", usage);
    }

    private int parseSeconds(String str) {
        try {
            if (str.endsWith("m")) return Integer.parseInt(str.replace("m", "")) * 60;
            if (str.endsWith("h")) return Integer.parseInt(str.replace("h", "")) * 3600;
            return Integer.parseInt(str);
        } catch (Exception e) {
            return 600;
        }
    }

    // -------------------------------------------------------
    //   TAB COMPLETION
    // -------------------------------------------------------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            List<String> cmds = Arrays.asList("set", "setmax", "addmax", "remmax", "add", "remove",
                "eliminate", "revive", "status", "giveitem", "togglerevives", "manualkill", "search",
                "reload", "version", "debuginfo", "top", "withdraw", "deposit", "pay", "streak",
                "freeze", "bypass", "event", "inspect", "simulate", "backup", "export", "import", "setheartmaterial", "setheartskin", "admin",
                "webhook", "license", "resetall", "reviveall", "recipes", "help");
            for (String c : cmds) {
                if (c.startsWith(args[0].toLowerCase())) completions.add(c);
            }
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "set": case "setmax": case "addmax": case "remmax": case "add": case "remove":
                case "eliminate": case "revive": case "status": case "giveitem": case "manualkill":
                case "freeze": case "inspect": case "debuginfo": case "streak":
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                            completions.add(p.getName());
                        }
                    }
                    break;
                case "admin":
                    completions.addAll(Arrays.asList("info", "setmaterial", "setskin", "setrevivecost",
                        "setstealamount", "setmaxhearts", "setminhearts", "setstartinghearts",
                        "setmobdeath", "setnaturaldeath", "setbantime", "setmode", "resetall", "reviveall", "unban"));
                    break;
                case "setheartmaterial":
                    for (org.bukkit.Material m : org.bukkit.Material.values()) {
                        if (!m.isLegacy() && m.isItem() && m.name().toLowerCase().startsWith(args[1].toLowerCase())) {
                            completions.add(m.name());
                            if (completions.size() >= 20) break;
                        }
                    }
                    break;
                case "top":
                    completions.addAll(Arrays.asList("hearts", "kills", "elim", "deaths"));
                    break;
                case "event":
                    completions.addAll(Arrays.asList("start", "stop"));
                    break;
                case "backup":
                    completions.addAll(Arrays.asList("create", "restore"));
                    break;
                case "export":
                    completions.addAll(Arrays.asList("csv", "json"));
                    break;
                case "webhook":
                    completions.add("test");
                    break;
                case "license":
                    completions.addAll(Arrays.asList("status", "activate"));
                    break;
                case "togglerevives":
                    completions.addAll(Arrays.asList("true", "false"));
                    break;
            }
        } else if (args.length == 3) {
            switch (args[0].toLowerCase()) {
                case "event":
                    completions.addAll(Arrays.asList("double", "rain"));
                    break;
                case "bypass":
                    completions.addAll(Arrays.asList("on", "off"));
                    break;
                case "admin":
                    switch (args[1].toLowerCase()) {
                        case "setmobdeath": case "setnaturaldeath":
                            completions.addAll(Arrays.asList("on", "off")); break;
                        case "setmode":
                            completions.addAll(Arrays.asList("BAN", "SPECTATOR", "KICK", "COMMAND")); break;
                        case "setbantime":
                            completions.addAll(Arrays.asList("1d", "3d", "7d", "12h", "24h")); break;
                        case "unban":
                            for (Player p : Bukkit.getOnlinePlayers()) {
                                if (p.getName().toLowerCase().startsWith(args[2].toLowerCase()))
                                    completions.add(p.getName());
                            }
                            break;
                        case "setmaterial":
                            for (org.bukkit.Material m : org.bukkit.Material.values()) {
                                if (!m.isLegacy() && m.isItem() && m.name().toLowerCase().startsWith(args[2].toLowerCase())) {
                                    completions.add(m.name());
                                    if (completions.size() >= 20) break;
                                }
                            }
                            break;
                    }
                    break;
                case "giveitem":
                    completions.addAll(Arrays.asList("heart", "negativeheart", "protect"));
                    break;
                case "manualkill": case "simulate":
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        if (p.getName().toLowerCase().startsWith(args[2].toLowerCase())) {
                            completions.add(p.getName());
                        }
                    }
                    break;
            }
        }

        return completions;
    }
}
