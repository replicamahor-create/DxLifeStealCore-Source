package dev.dxlifesteal.gui;

import dev.dxlifesteal.DxLifeStealCore;
import dev.dxlifesteal.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class RecipesGUI implements Listener {

    private final DxLifeStealCore plugin;

    // GUI Titles
    private static final String MAIN_TITLE   = "<dark_gray>⚗ <gradient:#FF4444:#FF0000>LifeSteal Recipes</gradient>";
    private static final String HEART_TITLE  = "<dark_gray>❤ <gradient:#FF4444:#FF0000>Heart Recipe</gradient>";
    private static final String NEG_TITLE    = "<dark_gray>🖤 <gradient:#333333:#888888>Cursed Heart Recipe</gradient>";
    private static final String SHIELD_TITLE = "<dark_gray>🛡 <gradient:#FFD700:#FFA500>Heart Shield Recipe</gradient>";
    private static final String REVIVE_TITLE = "<dark_gray>📖 <gradient:#00FF00:#008800>Revive Book Recipe</gradient>";

    public RecipesGUI(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------
    //   OPEN MAIN MENU — 27 slots, 4 recipe buttons in middle
    // -------------------------------------------------------
    public void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, ColorUtil.parse(MAIN_TITLE));

        // Fill border (slots 0-8, 18-26) with black glass
        ItemStack border = makeItem(Material.BLACK_STAINED_GLASS_PANE, "<dark_gray> ", null);
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, border);
        }

        // ── Row 1 border (slots 9,17) ──
        inv.setItem(9,  border);
        inv.setItem(17, border);

        // ── 4 Recipe Buttons in middle row ──

        // Slot 11 — Heart Recipe
        ItemStack heartBtn = plugin.getItemManager().createHeartItem(1);
        setDisplayName(heartBtn, "<red>❤ Heart Recipe");
        setLore(heartBtn,
            "<gray>Click to view the",
            "<white>Heart</white> <gray>crafting recipe.");
        inv.setItem(11, heartBtn);

        // Slot 12 — Negative Heart Recipe
        ItemStack negBtn = plugin.getItemManager().createNegativeHeartItem(1);
        setDisplayName(negBtn, "<dark_gray>🖤 Cursed Heart Recipe");
        setLore(negBtn,
            "<gray>Click to view the",
            "<white>Cursed Heart</white> <gray>crafting recipe.");
        inv.setItem(12, negBtn);

        // Slot 14 — Heart Shield Recipe
        ItemStack shieldBtn = plugin.getItemManager().createProtectItem(1);
        setDisplayName(shieldBtn, "<gold>🛡 Heart Shield Recipe");
        setLore(shieldBtn,
            "<gray>Click to view the",
            "<white>Heart Shield</white> <gray>crafting recipe.");
        inv.setItem(14, shieldBtn);

        // Slot 15 — Revive Book Recipe
        ItemStack reviveBtn = plugin.getItemManager().createReviveBook(1);
        setDisplayName(reviveBtn, "<green>📖 Revive Book Recipe");
        setLore(reviveBtn,
            "<gray>Click to view the",
            "<white>Revive Book</white> <gray>crafting recipe.");
        inv.setItem(15, reviveBtn);

        player.openInventory(inv);
    }

    // -------------------------------------------------------
    //   OPEN RECIPE VIEW — 27 slot crafting table style
    //
    //   Layout (27 slots, rows of 9):
    //   Row 0: [filler] [filler] [filler] [filler] [filler] [filler] [filler] [filler] [filler]
    //   Row 1: [filler] [s1][s2][s3] [filler] [=>] [RESULT] [filler]
    //   Row 2: [filler] [s4][s5][s6] [filler] [filler] [filler] [filler]
    //   Row 3: [filler] [s7][s8][s9] [filler] [back] [filler] [filler]
    //
    //   3x3 grid slots: 10,11,12 / 19,20,21 / 28... wait 27 slot = 3 rows
    //   Let me use a cleaner 27-slot layout:
    //
    //   Slot indexes (27 total):
    //   0  1  2  3  4  5  6  7  8
    //   9  10 11 12 13 14 15 16 17
    //   18 19 20 21 22 23 24 25 26
    //
    //   Grid at: 9,10,11 / 18,19,20 / ... no - 3x3 fits in:
    //   Cols 1-3 = slots 1,2,3 / 10,11,12 / 19,20,21
    //   Arrow at col 5 = slots 5,14,23
    //   Result at col 7 = slot 16
    //   Back at slot 26
    // -------------------------------------------------------
    private void openRecipeView(Player player, String title,
                                 Material[] grid,   // 9 items (null = air)
                                 ItemStack result) {

        Inventory inv = Bukkit.createInventory(null, 27, ColorUtil.parse(title));

        // Background filler
        ItemStack filler = makeItem(Material.GRAY_STAINED_GLASS_PANE, "<dark_gray> ", null);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        // 3x3 recipe grid
        // Row 0 of grid → inv slots 1,2,3
        // Row 1 of grid → inv slots 10,11,12
        // Row 2 of grid → inv slots 19,20,21
        int[] gridSlots = {1, 2, 3, 10, 11, 12, 19, 20, 21};
        for (int i = 0; i < 9; i++) {
            if (grid[i] != null) {
                inv.setItem(gridSlots[i], new ItemStack(grid[i]));
            } else {
                inv.setItem(gridSlots[i], makeItem(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "<dark_gray> ", null));
            }
        }

        // Arrow (crafting arrow indicator) at slot 5, 14
        ItemStack arrow = makeItem(Material.ARROW, "<gray>➜ Crafts into", null);
        inv.setItem(5, arrow);
        inv.setItem(14, filler);

        // Result item at slot 7
        inv.setItem(7, result);

        // Back button at slot 26
        ItemStack back = makeItem(Material.BARRIER, "<red>← Back", Arrays.asList("<gray>Return to recipes menu"));
        inv.setItem(26, back);

        player.openInventory(inv);
    }

    // -------------------------------------------------------
    //   CLICK HANDLER
    // -------------------------------------------------------
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        String rawTitle = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
            .plainText().serialize(event.getView().title());

        event.setCancelled(true); // Cancel all clicks in our GUIs

        // ── Main Menu clicks ──
        if (rawTitle.contains("LifeSteal Recipes")) {
            int slot = event.getSlot();

            if (slot == 11) openHeartRecipe(player);
            else if (slot == 12) openNegativeHeartRecipe(player);
            else if (slot == 14) openShieldRecipe(player);
            else if (slot == 15) openReviveBookRecipe(player);
        }

        // ── Recipe View — Back button ──
        if (rawTitle.contains("Recipe") &&
            (rawTitle.contains("Heart") || rawTitle.contains("Cursed") ||
             rawTitle.contains("Shield") || rawTitle.contains("Revive"))) {

            if (event.getSlot() == 26) {
                openMainMenu(player);
            }
        }
    }

    // -------------------------------------------------------
    //   INDIVIDUAL RECIPE OPENERS
    // -------------------------------------------------------

    private void openHeartRecipe(Player player) {
        // G N G
        // N D N
        // G N G
        Material[] grid = {
            Material.GOLD_BLOCK,      Material.NETHER_STAR,    Material.GOLD_BLOCK,
            Material.NETHER_STAR,     Material.DRAGON_EGG,     Material.NETHER_STAR,
            Material.GOLD_BLOCK,      Material.NETHER_STAR,    Material.GOLD_BLOCK
        };
        openRecipeView(player, HEART_TITLE, grid, plugin.getItemManager().createHeartItem(1));
    }

    private void openNegativeHeartRecipe(Player player) {
        // W W W
        // W S W
        // W W W
        Material[] grid = {
            Material.WITHER_SKELETON_SKULL, Material.WITHER_SKELETON_SKULL, Material.WITHER_SKELETON_SKULL,
            Material.WITHER_SKELETON_SKULL, Material.SOUL_SAND,             Material.WITHER_SKELETON_SKULL,
            Material.WITHER_SKELETON_SKULL, Material.WITHER_SKELETON_SKULL, Material.WITHER_SKELETON_SKULL
        };
        openRecipeView(player, NEG_TITLE, grid, plugin.getItemManager().createNegativeHeartItem(1));
    }

    private void openShieldRecipe(Player player) {
        // T G T
        // G D G
        // T G T
        Material[] grid = {
            Material.TOTEM_OF_UNDYING, Material.GHAST_TEAR,      Material.TOTEM_OF_UNDYING,
            Material.GHAST_TEAR,       Material.DIAMOND_BLOCK,   Material.GHAST_TEAR,
            Material.TOTEM_OF_UNDYING, Material.GHAST_TEAR,      Material.TOTEM_OF_UNDYING
        };
        openRecipeView(player, SHIELD_TITLE, grid, plugin.getItemManager().createProtectItem(1));
    }

    private void openReviveBookRecipe(Player player) {
        // E T E
        // T B T
        // E T E
        Material[] grid = {
            Material.EMERALD_BLOCK,    Material.TOTEM_OF_UNDYING, Material.EMERALD_BLOCK,
            Material.TOTEM_OF_UNDYING, Material.WRITTEN_BOOK,     Material.TOTEM_OF_UNDYING,
            Material.EMERALD_BLOCK,    Material.TOTEM_OF_UNDYING, Material.EMERALD_BLOCK
        };
        openRecipeView(player, REVIVE_TITLE, grid, plugin.getItemManager().createReviveBook(1));
    }

    // -------------------------------------------------------
    //   ITEM HELPERS
    // -------------------------------------------------------

    private ItemStack makeItem(Material mat, String name, java.util.List<String> loreList) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse(name));
        if (loreList != null) {
            meta.lore(loreList.stream()
                .map(ColorUtil::parse)
                .collect(java.util.stream.Collectors.toList()));
        }
        item.setItemMeta(meta);
        return item;
    }

    private void setDisplayName(ItemStack item, String name) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.displayName(ColorUtil.parse(name));
        item.setItemMeta(meta);
    }

    private void setLore(ItemStack item, String... lines) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.lore(Arrays.stream(lines)
            .map(ColorUtil::parse)
            .collect(java.util.stream.Collectors.toList()));
        item.setItemMeta(meta);
    }
}
