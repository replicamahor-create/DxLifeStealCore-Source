package dev.dxlifesteal.listeners;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener implements Listener {

    private final DxLifeStealCore plugin;

    public PlayerQuitListener(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getHeartManager().savePlayer(event.getPlayer());
    }
}
