package dev.dxlifesteal.listeners;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {

    private final DxLifeStealCore plugin;

    public PlayerJoinListener(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getHeartManager().loadPlayer(event.getPlayer());
        plugin.getEventManager().showBossBarToPlayer(event.getPlayer());
    }
}
