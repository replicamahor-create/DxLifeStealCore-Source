package dev.dxlifesteal.listeners;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;

public class PlayerRespawnListener implements Listener {

    private final DxLifeStealCore plugin;

    public PlayerRespawnListener(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getHeartManager().applyHearts(event.getPlayer());
        }, 1L);
    }
}
