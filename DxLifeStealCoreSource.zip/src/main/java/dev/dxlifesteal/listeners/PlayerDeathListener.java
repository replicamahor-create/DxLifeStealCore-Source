package dev.dxlifesteal.listeners;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class PlayerDeathListener implements Listener {

    private final DxLifeStealCore plugin;

    public PlayerDeathListener(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        // Check frozen
        if (plugin.getHeartManager().isFrozen(victim.getUniqueId())) return;

        // Check revive immunity
        if (plugin.getHeartManager().hasReviveImmunity(victim.getUniqueId())) return;

        if (killer != null && killer != victim) {
            // PvP kill - steal heart
            if (!plugin.getCooldownManager().canSteal(killer.getUniqueId())) return;

            plugin.getCooldownManager().setStealCooldown(killer.getUniqueId());
            plugin.getHeartManager().stealHeart(killer, victim);

        } else {
            // Non-PvP death (mob, fall, fire, void, etc.)
            boolean mobKill = victim.getLastDamageCause() != null &&
                isMobCause(victim.getLastDamageCause().getCause());

            if (mobKill) {
                // Check config: lose heart on mob death?
                if (plugin.getConfigManager().isLoseHeartOnMobDeath()) {
                    plugin.getHeartManager().removeHearts(
                        victim.getUniqueId(),
                        plugin.getConfigManager().getLoseAmount()
                    );
                }
            } else {
                // Natural/environment death (fall, fire, void, etc.)
                if (plugin.getConfigManager().isLoseHeartOnNaturalDeath()) {
                    plugin.getHeartManager().removeHearts(
                        victim.getUniqueId(),
                        plugin.getConfigManager().getLoseAmount()
                    );
                }
            }
        }

        // Reset streak on death
        plugin.getStreakManager().resetStreak(victim);
    }

    private boolean isMobCause(org.bukkit.event.entity.EntityDamageEvent.DamageCause cause) {
        switch (cause) {
            case ENTITY_ATTACK:
            case ENTITY_EXPLOSION:
            case ENTITY_SWEEP_ATTACK:
            case PROJECTILE:
            case MAGIC:
            case POISON:
            case WITHER:
            case THORNS:
                return true;
            default:
                return false;
        }
    }
}
