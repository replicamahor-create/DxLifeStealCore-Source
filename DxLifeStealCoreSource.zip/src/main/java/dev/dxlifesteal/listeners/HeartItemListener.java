package dev.dxlifesteal.listeners;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class HeartItemListener implements Listener {

    private final DxLifeStealCore plugin;

    public HeartItemListener(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() == EquipmentSlot.OFF_HAND) return;
        if (!event.getAction().name().contains("RIGHT_CLICK")) return;

        ItemStack item = event.getItem();
        if (item == null) return;

        Player player = event.getPlayer();

        // -------------------------------------------------------
        //   HEART ITEM
        // -------------------------------------------------------
        if (plugin.getItemManager().isHeartItem(item)) {
            event.setCancelled(true);

            if (!plugin.getCooldownManager().canUse(player.getUniqueId())) {
                long left = plugin.getCooldownManager().getUseCooldownLeft(player.getUniqueId());
                plugin.getMessageManager().send(player, "items.cooldown", "%seconds%", String.valueOf(left));
                return;
            }

            int current = plugin.getHeartManager().getHearts(player.getUniqueId());
            int max = plugin.getHeartManager().getMaxHearts(player.getUniqueId());
            if (current >= max) {
                plugin.getMessageManager().send(player, "hearts.max-reached", "%max%", String.valueOf(max));
                return;
            }

            plugin.getCooldownManager().setUseCooldown(player.getUniqueId());
            plugin.getHeartManager().addHearts(player.getUniqueId(), 1);

            // Consume item (skip in creative mode)
            if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
                if (item.getAmount() > 1) item.setAmount(item.getAmount() - 1);
                else player.getInventory().setItemInMainHand(null);
            }

            plugin.getMessageManager().send(player, "items.used",
                "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(player.getUniqueId())));

            // TOTEM FATA EFFECT
            playTotemPopEffect(player);
        }

        // -------------------------------------------------------
        //   NEGATIVE HEART ITEM
        // -------------------------------------------------------
        else if (plugin.getItemManager().isNegativeHeartItem(item)) {
            event.setCancelled(true);

            if (!plugin.getCooldownManager().canUse(player.getUniqueId())) {
                long left = plugin.getCooldownManager().getUseCooldownLeft(player.getUniqueId());
                plugin.getMessageManager().send(player, "items.cooldown", "%seconds%", String.valueOf(left));
                return;
            }

            plugin.getCooldownManager().setUseCooldown(player.getUniqueId());
            plugin.getHeartManager().removeHearts(player.getUniqueId(), 1);

            // Consume item (skip in creative mode)
            if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
                if (item.getAmount() > 1) item.setAmount(item.getAmount() - 1);
                else player.getInventory().setItemInMainHand(null);
            }

            plugin.getMessageManager().send(player, "items.used-negative",
                "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(player.getUniqueId())));

            playNegativeHeartEffect(player);
        }

        // -------------------------------------------------------
        //   REVIVE BOOK - Right click to revive eliminated player
        // -------------------------------------------------------
        else if (plugin.getItemManager().isReviveBook(item)) {
            event.setCancelled(true);

            if (!(player instanceof org.bukkit.entity.Player)) return;

            // Check if looking at a player (or use command fallback)
            org.bukkit.block.Block target = player.getTargetBlockExact(5);
            // Find nearest eliminated player within 5 blocks
            org.bukkit.entity.Player nearestElim = null;
            double closest = 6.0;

            for (org.bukkit.entity.Player online : plugin.getServer().getOnlinePlayers()) {
                if (online == player) continue;
                if (!plugin.getHeartManager().isEliminated(online.getUniqueId())) continue;
                double dist = online.getLocation().distance(player.getLocation());
                if (dist < closest) {
                    closest = dist;
                    nearestElim = online;
                }
            }

            if (nearestElim == null) {
                player.sendMessage(dev.dxlifesteal.utils.ColorUtil.parse(
                    "<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] <red>⚠ No eliminated player nearby to revive!"));
                return;
            }

            // Revive them
            plugin.getEliminationManager().revive(player, nearestElim);

            // Consume book (skip in creative mode)
            if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
                if (item.getAmount() > 1) item.setAmount(item.getAmount() - 1);
                else player.getInventory().setItemInMainHand(null);
            }

            // Revive book effect
            playReviveBookEffect(player);
        }
    }

    // -------------------------------------------------------
    //   TOTEM FATA EFFECT - No inventory, no item, pure effect
    // -------------------------------------------------------
    private void playTotemPopEffect(Player player) {

        // Trigger exact totem screen animation via reflection
        // Status byte 35 = totem resurrection animation in Minecraft protocol
        try {
            // Get NMS player handle
            Object nmsPlayer = player.getClass().getMethod("getHandle").invoke(player);

            // Find connection field (works across versions via reflection)
            Object connection = null;
            for (java.lang.reflect.Field f : nmsPlayer.getClass().getFields()) {
                String typeName = f.getType().getSimpleName();
                if (typeName.contains("Connection") || typeName.contains("NetworkManager")
                    || typeName.contains("PlayerConnection")) {
                    f.setAccessible(true);
                    connection = f.get(nmsPlayer);
                    break;
                }
            }

            if (connection == null) {
                // Try superclass fields
                for (java.lang.reflect.Field f : nmsPlayer.getClass().getSuperclass().getFields()) {
                    f.setAccessible(true);
                    Object val = f.get(nmsPlayer);
                    if (val != null && val.getClass().getSimpleName().toLowerCase().contains("connect")) {
                        connection = val;
                        break;
                    }
                }
            }

            // Find packet class
            Class<?> packetClass = null;
            for (String name : new String[]{
                "net.minecraft.network.protocol.game.ClientboundEntityEventPacket",
                "net.minecraft.network.protocol.game.PacketPlayOutEntityStatus"}) {
                try { packetClass = Class.forName(name); break; }
                catch (ClassNotFoundException ignored) {}
            }

            if (packetClass != null && connection != null) {
                // Create packet: entity + status 35 (totem pop)
                Object packet = packetClass.getConstructors()[0].newInstance(nmsPlayer, (byte) 35);

                // Send packet via send/a/sendPacket method
                for (java.lang.reflect.Method m : connection.getClass().getMethods()) {
                    if (m.getParameterCount() == 1 &&
                        m.getParameterTypes()[0].isAssignableFrom(packetClass)) {
                        m.invoke(connection, packet);
                        break;
                    }
                }
            }
        } catch (Exception ignored) {
            // Silent fallback - particles only if packet fails
        }

        // Always run these - they work on all versions
        // TOTEM_OF_UNDYING particle = the actual screen orange flash effect
        player.getWorld().spawnParticle(
            Particle.TOTEM_OF_UNDYING,
            player.getLocation().add(0, 1, 0),
            150, 0.6, 1.0, 0.6, 0.5
        );

        // Real totem potion effects
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 40, 1, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1, false, true));

        // Step 6: Red heart spiral around player
        new BukkitRunnable() {
            double angle = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= 20) { cancel(); return; }

                for (int i = 0; i < 2; i++) {
                    double x = Math.cos(angle + i * Math.PI) * 0.8;
                    double z = Math.sin(angle + i * Math.PI) * 0.8;
                    player.getWorld().spawnParticle(
                        Particle.HEART,
                        player.getLocation().add(x, 1.2, z),
                        1, 0, 0, 0, 0
                    );
                }

                // Red rising dust
                Particle.DustOptions redDust = new Particle.DustOptions(Color.RED, 1.5f);
                player.getWorld().spawnParticle(Particle.DUST,
                    player.getLocation().add(
                        (Math.random() - 0.5) * 1.2,
                        Math.random() * 2.2,
                        (Math.random() - 0.5) * 1.2),
                    1, 0, 0, 0, 0, redDust);

                angle += Math.PI / 5;
                ticks++;
            }
        }.runTaskTimer(plugin, 2L, 1L);

        // Step 7: Sounds - exactly like totem pop
        player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1.0f, 1.0f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f), 8L);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.5f, 2.0f), 15L);

        // Step 8: White flash at end
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            Particle.DustOptions whiteDust = new Particle.DustOptions(Color.WHITE, 2.0f);
            player.getWorld().spawnParticle(Particle.DUST,
                player.getLocation().add(0, 1, 0),
                30, 0.5, 0.5, 0.5, 0, whiteDust);
        }, 18L);
    }

    // -------------------------------------------------------
    //   NEGATIVE HEART - Dark wither effect
    // -------------------------------------------------------
    private void playNegativeHeartEffect(Player player) {
        Location loc = player.getLocation().add(0, 1, 0);

        // Dark smoke burst
        player.getWorld().spawnParticle(Particle.LARGE_SMOKE, loc, 30, 0.4, 0.5, 0.4, 0.05);

        // Black dust spiral
        new BukkitRunnable() {
            double angle = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= 15) { cancel(); return; }

                Particle.DustOptions blackDust = new Particle.DustOptions(Color.BLACK, 1.5f);
                for (int i = 0; i < 3; i++) {
                    double x = Math.cos(angle + i * (2 * Math.PI / 3)) * 0.8;
                    double z = Math.sin(angle + i * (2 * Math.PI / 3)) * 0.8;
                    player.getWorld().spawnParticle(Particle.DUST,
                        player.getLocation().add(x, 1.0 + (ticks * 0.05), z),
                        1, 0, 0, 0, 0, blackDust);
                }

                player.getWorld().spawnParticle(Particle.ASH,
                    player.getLocation().add(
                        (Math.random() - 0.5) * 1.5, 2.0,
                        (Math.random() - 0.5) * 1.5),
                    2, 0.1, 0.1, 0.1, 0.02);

                angle += Math.PI / 4;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        player.getWorld().spawnParticle(Particle.SQUID_INK, loc, 15, 0.3, 0.4, 0.3, 0.05);

        // Sounds
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_HURT, 1.0f, 0.6f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 0.7f, 0.8f), 5L);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.BLOCK_SOUL_SAND_PLACE, 1.0f, 0.5f), 8L);
    }

    // -------------------------------------------------------
    //   REVIVE BOOK EFFECT
    // -------------------------------------------------------
    private void playReviveBookEffect(Player player) {
        // Green explosion of particles
        player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING,
            player.getLocation().add(0, 1, 0), 60, 0.5, 0.8, 0.5, 0.2);

        new BukkitRunnable() {
            double angle = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= 20) { cancel(); return; }

                for (int i = 0; i < 3; i++) {
                    double x = Math.cos(angle + i * (2 * Math.PI / 3)) * 1.0;
                    double z = Math.sin(angle + i * (2 * Math.PI / 3)) * 1.0;
                    Particle.DustOptions greenDust = new Particle.DustOptions(Color.LIME, 1.8f);
                    player.getWorld().spawnParticle(Particle.DUST,
                        player.getLocation().add(x, 1.2, z), 1, 0, 0, 0, 0, greenDust);
                }

                player.getWorld().spawnParticle(Particle.HEART,
                    player.getLocation().add(
                        (Math.random() - 0.5) * 1.5, 1.5,
                        (Math.random() - 0.5) * 1.5),
                    1, 0, 0, 0, 0);

                angle += Math.PI / 6;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.8f), 10L);
    }

}