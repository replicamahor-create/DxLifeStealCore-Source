package dev.dxlifesteal.tasks;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.scheduler.BukkitRunnable;

public class AutoSaveTask extends BukkitRunnable {

    private final DxLifeStealCore plugin;
    private int scheduledSaveTick = 0;

    public AutoSaveTask(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        // Every tick (1 second) - flush dirty player YML files to disk
        for (org.bukkit.entity.Player player : plugin.getServer().getOnlinePlayers()) {
            plugin.getHeartManager().flushToYml(player.getUniqueId());
        }
        plugin.getDatabaseManager().saveDirty();

        // Every 5 minutes - log scheduled save to console (like LifeStealCore)
        scheduledSaveTick++;
        if (scheduledSaveTick >= 300) {
            scheduledSaveTick = 0;
            long start = System.currentTimeMillis();
            plugin.getDatabaseManager().saveAll();
            long ms = System.currentTimeMillis() - start;
            plugin.getLogger().info("[Scheduled Save] Saved data to file... " + ms + "ms");
        }
    }
}
