package dev.dxlifesteal.tasks;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.scheduler.BukkitRunnable;

public class EventTask extends BukkitRunnable {

    private final DxLifeStealCore plugin;

    public EventTask(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        plugin.getEventManager().tick();
    }
}
