package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import dev.dxlifesteal.utils.ColorUtil;
import org.bukkit.command.CommandSender;

import java.util.List;

public class LeaderboardManager {

    private final DxLifeStealCore plugin;

    public LeaderboardManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void sendLeaderboard(CommandSender sender, String type, int size) {
        String field;
        String typeDisplay;

        switch (type.toLowerCase()) {
            case "kills":       field = "kills";        typeDisplay = "⚔ Top Kills";        break;
            case "elim":
            case "eliminations": field = "eliminations"; typeDisplay = "💀 Top Eliminations"; break;
            case "deaths":      field = "deaths";       typeDisplay = "☠ Top Deaths";        break;
            default:            field = "hearts";       typeDisplay = "❤ Top Hearts";        break;
        }

        int leaderboardSize = size > 0 ? size : plugin.getConfigManager().getLeaderboardSize();

        // Run async so file scanning doesn't lag main thread
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            List<String[]> entries = plugin.getDatabaseManager().getTopPlayers(field, leaderboardSize);

            plugin.getServer().getScheduler().runTask(plugin, () -> {
                sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("leaderboard.header")));
                sender.sendMessage(ColorUtil.parse(
                    plugin.getMessageManager().getRaw("leaderboard.title")
                        .replace("%type%", typeDisplay)));

                if (entries.isEmpty()) {
                    sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("leaderboard.no-data")));
                } else {
                    for (int i = 0; i < entries.size(); i++) {
                        String[] entry = entries.get(i);
                        sender.sendMessage(ColorUtil.parse(
                            plugin.getMessageManager().getRaw("leaderboard.entry")
                                .replace("%rank%", String.valueOf(i + 1))
                                .replace("%player%", entry[0])
                                .replace("%value%", entry[1])));
                    }
                }

                sender.sendMessage(ColorUtil.parse(plugin.getMessageManager().getRaw("leaderboard.footer")));
            });
        });
    }
}
