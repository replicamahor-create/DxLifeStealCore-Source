package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import dev.dxlifesteal.utils.ColorUtil;
import org.bukkit.entity.Player;

public class EventManager {

    private final DxLifeStealCore plugin;

    private boolean doubleHeartsActive = false;
    private boolean heartRainActive = false;
    private int doubleHeartsTimeLeft = 0;
    private int heartRainTimeLeft = 0;
    private int heartRainTick = 0;

    private BossBar doubleHeartsBossBar;

    public EventManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------
    //   DOUBLE HEARTS EVENT
    // -------------------------------------------------------

    public void startDoubleHearts(int durationSeconds) {
        doubleHeartsActive = true;
        doubleHeartsTimeLeft = durationSeconds;

        // Create bossbar
        doubleHeartsBossBar = BossBar.bossBar(
            ColorUtil.parse(plugin.getMessageManager().get("events.double-hearts.bossbar",
                "%time%", formatTime(durationSeconds))),
            1.0f,
            BossBar.Color.RED,
            BossBar.Overlay.PROGRESS
        );

        // Show to all players
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            player.showBossBar(doubleHeartsBossBar);
        }

        plugin.getMessageManager().broadcast("events.double-hearts.start",
            "%duration%", formatTime(durationSeconds));
    }

    public void stopDoubleHearts() {
        doubleHeartsActive = false;
        doubleHeartsTimeLeft = 0;

        if (doubleHeartsBossBar != null) {
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                player.hideBossBar(doubleHeartsBossBar);
            }
            doubleHeartsBossBar = null;
        }

        plugin.getMessageManager().broadcast("events.double-hearts.end");
    }

    // -------------------------------------------------------
    //   HEART RAIN EVENT
    // -------------------------------------------------------

    public void startHeartRain(int durationSeconds) {
        heartRainActive = true;
        heartRainTimeLeft = durationSeconds;
        heartRainTick = 0;
        plugin.getMessageManager().broadcast("events.heart-rain.start",
            "%interval%", String.valueOf(plugin.getConfigManager().getHeartRainInterval()));
    }

    public void stopHeartRain() {
        heartRainActive = false;
        heartRainTimeLeft = 0;
        plugin.getMessageManager().broadcast("events.heart-rain.end");
    }

    // -------------------------------------------------------
    //   TICK (called every second from EventTask)
    // -------------------------------------------------------

    public void tick() {
        // Double hearts timer
        if (doubleHeartsActive) {
            doubleHeartsTimeLeft--;
            if (doubleHeartsBossBar != null) {
                // Update bossbar
                // (simplified - full implementation would update name and progress)
            }
            if (doubleHeartsTimeLeft <= 0) {
                stopDoubleHearts();
            }
        }

        // Heart rain
        if (heartRainActive) {
            heartRainTimeLeft--;
            heartRainTick++;

            int interval = plugin.getConfigManager().getHeartRainInterval();
            int amount = plugin.getConfigManager().getHeartRainAmount();

            if (heartRainTick >= interval) {
                heartRainTick = 0;
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    plugin.getHeartManager().addHearts(player.getUniqueId(), amount);
                    plugin.getMessageManager().send(player, "events.heart-rain.receive",
                        "%amount%", String.valueOf(amount));
                }
            }

            if (heartRainTimeLeft <= 0) {
                stopHeartRain();
            }
        }
    }

    public void showBossBarToPlayer(Player player) {
        if (doubleHeartsActive && doubleHeartsBossBar != null) {
            player.showBossBar(doubleHeartsBossBar);
        }
    }

    private String formatTime(int seconds) {
        if (seconds >= 3600) return (seconds / 3600) + "h " + ((seconds % 3600) / 60) + "m";
        if (seconds >= 60) return (seconds / 60) + "m " + (seconds % 60) + "s";
        return seconds + "s";
    }

    // Getters
    public boolean isDoubleHeartsActive() { return doubleHeartsActive; }
    public boolean isHeartRainActive() { return heartRainActive; }
    public int getDoubleHeartsTimeLeft() { return doubleHeartsTimeLeft; }
    public int getHeartRainTimeLeft() { return heartRainTimeLeft; }
}
