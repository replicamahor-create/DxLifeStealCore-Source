package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StreakManager {

    private final DxLifeStealCore plugin;
    private final Map<UUID, Integer> streaks = new HashMap<>();
    private final Map<UUID, Integer> bestStreaks = new HashMap<>();

    public StreakManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void addKill(Player killer, Player victim) {
        if (!plugin.getConfigManager().isStreakEnabled()) return;

        UUID uuid = killer.getUniqueId();
        int newStreak = streaks.merge(uuid, 1, Integer::sum);

        // Update best streak
        int best = bestStreaks.getOrDefault(uuid, 0);
        if (newStreak > best) bestStreaks.put(uuid, newStreak);

        // Reset victim streak
        streaks.put(victim.getUniqueId(), 0);

        // Check milestone rewards
        Map<Integer, Integer> rewards = plugin.getConfigManager().getStreakRewards();
        if (rewards.containsKey(newStreak)) {
            int bonus = rewards.get(newStreak);
            plugin.getHeartManager().addHearts(uuid, bonus);
            plugin.getMessageManager().broadcast("streak.milestone",
                "%player%", killer.getName(),
                "%streak%", String.valueOf(newStreak),
                "%bonus%", String.valueOf(bonus));
        }
    }

    public void resetStreak(Player player) {
        int current = streaks.getOrDefault(player.getUniqueId(), 0);
        if (current > 0) {
            plugin.getMessageManager().broadcast("streak.reset",
                "%player%", player.getName(),
                "%streak%", String.valueOf(current));
        }
        streaks.put(player.getUniqueId(), 0);
    }

    public int getStreak(UUID uuid) { return streaks.getOrDefault(uuid, 0); }
    public int getBestStreak(UUID uuid) { return bestStreaks.getOrDefault(uuid, 0); }

    public void loadStreak(UUID uuid, int streak, int best) {
        streaks.put(uuid, streak);
        bestStreaks.put(uuid, best);
    }
}
