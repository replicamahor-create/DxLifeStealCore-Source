package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;

public class EliminationManager {

    private final DxLifeStealCore plugin;

    public EliminationManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void reload() {}

    public void eliminate(Player player, Player killer) {
        HeartManager hm = plugin.getHeartManager();
        hm.setHearts(player.getUniqueId(), 0);
        hm.setEliminated(player.getUniqueId(), true);
        hm.addElimination(player.getUniqueId());
        if (killer != null) hm.addElimination(killer.getUniqueId());

        plugin.getDatabaseManager().logHistory(player.getUniqueId(), "ELIMINATED", 0,
            killer != null ? killer.getUniqueId() : null);

        if (killer != null) {
            plugin.getMessageManager().broadcast("elimination.broadcast",
                "%player%", player.getName(), "%killer%", killer.getName());
        } else {
            plugin.getMessageManager().broadcast("elimination.self",
                "%player%", player.getName());
        }

        plugin.getDiscordManager().sendElimination(player.getName(),
            killer != null ? killer.getName() : "Unknown");

        plugin.getMessageManager().sendTitle(player,
            "titles.elimination.title", "titles.elimination.subtitle");

        // --- ELIMINATION EFFECTS ---
        playEliminationEffect(player);
        if (killer != null) playKillerEffect(killer);

        if (plugin.getConfigManager().isClearInventory()) player.getInventory().clear();
        if (plugin.getConfigManager().isClearEnderChest()) player.getEnderChest().clear();

        String mode = plugin.getConfigManager().getEliminationMode();

        new BukkitRunnable() {
            @Override
            public void run() {
                switch (mode.toUpperCase()) {
                    case "BAN":
                        long banDuration = parseDuration(plugin.getConfigManager().getBanDuration());
                        String banMsg = plugin.getMessageManager().get("elimination.ban-message",
                            "%duration%", plugin.getConfigManager().getBanDuration());
                        Bukkit.getBanList(BanList.Type.NAME).addBan(
                            player.getName(), banMsg,
                            new java.util.Date(System.currentTimeMillis() + banDuration),
                            "DxLifeStealCore"
                        );
                        player.kickPlayer(banMsg);
                        break;
                    case "SPECTATOR":
                        player.setGameMode(GameMode.SPECTATOR);
                        break;
                    case "KICK":
                        player.kickPlayer("You have been eliminated!");
                        break;
                    case "COMMAND":
                        String cmd = plugin.getConfigManager().getEliminationCommand()
                            .replace("%player%", player.getName());
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                        break;
                }
            }
        }.runTaskLater(plugin, 60L);
    }

    public void revive(Player reviver, Player target) {
        HeartManager hm = plugin.getHeartManager();

        if (!hm.isEliminated(target.getUniqueId())) {
            plugin.getMessageManager().send(reviver, "revive.not-eliminated", "%player%", target.getName());
            return;
        }
        if (!plugin.getConfigManager().isReviveEnabled()) {
            plugin.getMessageManager().send(reviver, "revive.disabled");
            return;
        }

        int cost = plugin.getConfigManager().getReviveCost();
        int reviverHearts = hm.getHearts(reviver.getUniqueId());

        if (reviverHearts < cost) {
            plugin.getMessageManager().send(reviver, "revive.not-enough-hearts",
                "%cost%", String.valueOf(cost),
                "%player%", target.getName(),
                "%hearts%", String.valueOf(reviverHearts));
            return;
        }

        hm.removeHearts(reviver.getUniqueId(), cost);
        Bukkit.getBanList(BanList.Type.NAME).pardon(target.getName());
        hm.setEliminated(target.getUniqueId(), false);
        hm.setHearts(target.getUniqueId(), plugin.getConfigManager().getStartingHearts());
        hm.addReviveImmunity(target.getUniqueId());

        plugin.getDatabaseManager().logHistory(target.getUniqueId(), "REVIVED", 0, reviver.getUniqueId());

        plugin.getMessageManager().send(reviver, "revive.success-reviver",
            "%player%", target.getName(), "%cost%", String.valueOf(cost));

        if (plugin.getConfigManager().isReviveAnnounce()) {
            plugin.getMessageManager().broadcast("revive.broadcast",
                "%reviver%", reviver.getName(),
                "%player%", target.getName(),
                "%cost%", String.valueOf(cost));
        }

        // --- REVIVE EFFECTS ---
        playReviveEffect(reviver);

        plugin.getDiscordManager().sendRevive(reviver.getName(), target.getName());
    }

    // -------------------------------------------------------
    //   ELIMINATION EFFECT - Dark explosion + wither skulls
    // -------------------------------------------------------
    private void playEliminationEffect(Player player) {
        Location loc = player.getLocation().add(0, 1, 0);

        // 1. Giant smoke explosion
        player.getWorld().spawnParticle(Particle.EXPLOSION, loc, 3, 0.3, 0.3, 0.3, 0);

        // 2. Black + red dust tornado
        new BukkitRunnable() {
            double angle = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= 30) { cancel(); return; }

                double radius = 1.5 - (ticks * 0.04);
                double height = ticks * 0.08;

                for (int i = 0; i < 4; i++) {
                    double x = Math.cos(angle + i * (Math.PI / 2)) * radius;
                    double z = Math.sin(angle + i * (Math.PI / 2)) * radius;

                    Particle.DustOptions redDust = new Particle.DustOptions(Color.RED, 2.0f);
                    Particle.DustOptions blackDust = new Particle.DustOptions(Color.BLACK, 1.5f);

                    player.getWorld().spawnParticle(Particle.DUST,
                        player.getLocation().add(x, height, z), 1, 0, 0, 0, 0, redDust);
                    player.getWorld().spawnParticle(Particle.DUST,
                        player.getLocation().add(-x, height + 0.2, -z), 1, 0, 0, 0, 0, blackDust);
                }

                // Lava drip falling
                if (ticks % 3 == 0) {
                    player.getWorld().spawnParticle(Particle.DRIPPING_LAVA,
                        player.getLocation().add(
                            (Math.random() - 0.5) * 2,
                            2.5,
                            (Math.random() - 0.5) * 2),
                        1, 0, 0, 0, 0);
                }

                angle += Math.PI / 6;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // 3. Skull cracks
        player.getWorld().spawnParticle(Particle.LARGE_SMOKE, loc, 20, 0.5, 0.8, 0.5, 0.05);

        // 4. Dark firework
        spawnDeathFirework(player.getLocation());

        // 5. Sounds - dramatic
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 1.0f, 0.8f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 0.5f), 5L);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 0.7f), 15L);
    }

    // -------------------------------------------------------
    //   KILLER EFFECT - Gold fireworks + celebration
    // -------------------------------------------------------
    private void playKillerEffect(Player killer) {
        // 1. Gold sparkle around killer
        new BukkitRunnable() {
            double angle = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= 25) { cancel(); return; }

                double x = Math.cos(angle) * 1.0;
                double z = Math.sin(angle) * 1.0;

                Particle.DustOptions goldDust = new Particle.DustOptions(Color.YELLOW, 1.5f);
                Particle.DustOptions orangeDust = new Particle.DustOptions(Color.ORANGE, 1.2f);

                killer.getWorld().spawnParticle(Particle.DUST,
                    killer.getLocation().add(x, 1.5, z), 2, 0, 0.1, 0, 0, goldDust);
                killer.getWorld().spawnParticle(Particle.DUST,
                    killer.getLocation().add(-x, 1.0, -z), 2, 0, 0.1, 0, 0, orangeDust);

                // Rising gold trail
                killer.getWorld().spawnParticle(Particle.END_ROD,
                    killer.getLocation().add(
                        (Math.random() - 0.5) * 1.5,
                        Math.random() * 2.5,
                        (Math.random() - 0.5) * 1.5),
                    1, 0, 0.05, 0, 0.02);

                angle += Math.PI / 8;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // 2. Victory firework
        spawnVictoryFirework(killer.getLocation());

        // 3. Victory sounds
        killer.playSound(killer.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f), 10L);
    }

    // -------------------------------------------------------
    //   REVIVE EFFECT - Green healing burst
    // -------------------------------------------------------
    private void playReviveEffect(Player reviver) {
        Location loc = reviver.getLocation().add(0, 1, 0);

        // 1. Green healing particles spiral
        new BukkitRunnable() {
            double angle = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= 25) { cancel(); return; }

                for (int i = 0; i < 3; i++) {
                    double x = Math.cos(angle + i * (2 * Math.PI / 3)) * 1.0;
                    double z = Math.sin(angle + i * (2 * Math.PI / 3)) * 1.0;

                    Particle.DustOptions greenDust = new Particle.DustOptions(Color.LIME, 1.5f);
                    reviver.getWorld().spawnParticle(Particle.DUST,
                        reviver.getLocation().add(x, 1.2, z), 1, 0, 0, 0, 0, greenDust);
                }

                // Rising sparkles
                reviver.getWorld().spawnParticle(Particle.END_ROD,
                    reviver.getLocation().add(
                        (Math.random() - 0.5) * 1.5,
                        Math.random() * 2.5,
                        (Math.random() - 0.5) * 1.5),
                    1, 0, 0.03, 0, 0.01);

                angle += Math.PI / 6;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // 2. Heart particles burst
        reviver.getWorld().spawnParticle(Particle.HEART, loc, 15, 0.5, 0.5, 0.5, 0.1);

        // 3. White flash
        Particle.DustOptions whiteDust = new Particle.DustOptions(Color.WHITE, 2.5f);
        reviver.getWorld().spawnParticle(Particle.DUST, loc, 40, 0.6, 0.6, 0.6, 0, whiteDust);

        // 4. Green firework
        spawnReviveFirework(reviver.getLocation());

        // 5. Healing sounds
        reviver.playSound(reviver.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.5f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            reviver.playSound(reviver.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.8f), 8L);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            reviver.playSound(reviver.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 2.0f), 15L);
    }

    // -------------------------------------------------------
    //   FIREWORK HELPERS
    // -------------------------------------------------------

    private void spawnDeathFirework(Location loc) {
        try {
            Firework fw = (Firework) loc.getWorld().spawnEntity(loc, EntityType.FIREWORK_ROCKET);
            FireworkMeta meta = fw.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                .withColor(Color.BLACK, Color.RED)
                .withFade(Color.GRAY)
                .with(FireworkEffect.Type.BURST)
                .trail(false)
                .flicker(true)
                .build());
            meta.setPower(0);
            fw.setFireworkMeta(meta);
            Bukkit.getScheduler().runTaskLater(plugin, fw::detonate, 3L);
        } catch (Exception e) {
            if (plugin.getConfigManager().isDebugMode())
                plugin.getLogger().warning("Death firework failed: " + e.getMessage());
        }
    }

    private void spawnVictoryFirework(Location loc) {
        try {
            Firework fw = (Firework) loc.getWorld().spawnEntity(
                loc.clone().add(0, 1, 0), EntityType.FIREWORK_ROCKET);
            FireworkMeta meta = fw.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                .withColor(Color.YELLOW, Color.ORANGE, Color.RED)
                .withFade(Color.WHITE)
                .with(FireworkEffect.Type.STAR)
                .trail(true)
                .flicker(true)
                .build());
            meta.setPower(1);
            fw.setFireworkMeta(meta);
        } catch (Exception e) {
            if (plugin.getConfigManager().isDebugMode())
                plugin.getLogger().warning("Victory firework failed: " + e.getMessage());
        }
    }

    private void spawnReviveFirework(Location loc) {
        try {
            Firework fw = (Firework) loc.getWorld().spawnEntity(
                loc.clone().add(0, 1, 0), EntityType.FIREWORK_ROCKET);
            FireworkMeta meta = fw.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                .withColor(Color.LIME, Color.GREEN, Color.WHITE)
                .withFade(Color.AQUA)
                .with(FireworkEffect.Type.BALL_LARGE)
                .trail(true)
                .flicker(false)
                .build());
            meta.setPower(0);
            fw.setFireworkMeta(meta);
            Bukkit.getScheduler().runTaskLater(plugin, fw::detonate, 3L);
        } catch (Exception e) {
            if (plugin.getConfigManager().isDebugMode())
                plugin.getLogger().warning("Revive firework failed: " + e.getMessage());
        }
    }

    private long parseDuration(String duration) {
        if (duration == null || duration.isEmpty()) return 259200000L;
        long multiplier = 1000L;
        if (duration.endsWith("d")) multiplier = 86400000L;
        else if (duration.endsWith("h")) multiplier = 3600000L;
        else if (duration.endsWith("m")) multiplier = 60000L;
        try {
            return Long.parseLong(duration.replaceAll("[^0-9]", "")) * multiplier;
        } catch (NumberFormatException e) { return 259200000L; }
    }
}
