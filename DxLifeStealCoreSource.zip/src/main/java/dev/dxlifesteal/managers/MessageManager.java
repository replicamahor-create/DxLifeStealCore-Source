package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import dev.dxlifesteal.utils.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.time.Duration;

public class MessageManager {

    private final DxLifeStealCore plugin;
    private FileConfiguration messages;
    private File messagesFile;

    public MessageManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
        load();
    }

    private void load() {
        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(messagesFile);
    }

    public void reload() {
        load();
    }

    public String getRaw(String path) {
        return messages.getString(path, "<red>Missing message: " + path);
    }

    public String get(String path, String... replacements) {
        String msg = getRaw(path);
        for (int i = 0; i < replacements.length - 1; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        return msg;
    }

    public Component getComponent(String path, String... replacements) {
        return ColorUtil.parse(get(path, replacements));
    }

    public void send(CommandSender sender, String path, String... replacements) {
        sender.sendMessage(getComponent(path, replacements));
    }

    public void sendTitle(Player player, String titlePath, String subtitlePath, String... replacements) {
        String titleStr = get(titlePath, replacements);
        String subtitleStr = get(subtitlePath, replacements);

        int fadeIn = messages.getInt(titlePath.replace(".title", ".fade-in"), 10);
        int stay = messages.getInt(titlePath.replace(".title", ".stay"), 40);
        int fadeOut = messages.getInt(titlePath.replace(".title", ".fade-out"), 10);

        Title title = Title.title(
            ColorUtil.parse(titleStr),
            ColorUtil.parse(subtitleStr),
            Title.Times.times(
                Duration.ofMillis(fadeIn * 50L),
                Duration.ofMillis(stay * 50L),
                Duration.ofMillis(fadeOut * 50L)
            )
        );
        player.showTitle(title);
    }

    public void broadcast(String path, String... replacements) {
        Component msg = getComponent(path, replacements);
        plugin.getServer().broadcast(msg);
    }

    public void set(String path, String value) {
        messages.set(path, value);
        try {
            messages.save(messagesFile);
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save messages.yml: " + e.getMessage());
        }
    }
}
