package dev.dxlifesteal.managers;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.dxlifesteal.DxLifeStealCore;
import dev.dxlifesteal.utils.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class ItemManager {

    private final DxLifeStealCore plugin;
    private static final String HEART_KEY = "dxlifesteal_heart";
    private static final String NEGATIVE_KEY = "dxlifesteal_negative";
    private static final String PROTECT_KEY = "dxlifesteal_protect";

    public ItemManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void reload() {}

    // -------------------------------------------------------
    //   HEART ITEM
    // -------------------------------------------------------

    public ItemStack createHeartItem(int amount) {
        String materialStr = plugin.getConfigManager().getHeartMaterial();
        String skinUrl = plugin.getConfigManager().getHeartSkinUrl();

        ItemStack item;
        if (skinUrl != null && !skinUrl.isEmpty()) {
            item = createSkullWithSkin(skinUrl);
        } else {
            Material mat = parseMaterial(materialStr, Material.NETHER_STAR);
            item = new ItemStack(mat, amount);
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse(plugin.getConfigManager().getHeartName()));
        meta.lore(plugin.getConfigManager().getHeartLore()
            .stream().map(ColorUtil::parse).collect(Collectors.toList()));

        if (plugin.getConfigManager().isHeartGlow()) {
            meta.addEnchant(Enchantment.getByName("PROTECTION_ENVIRONMENTAL") != null
                ? Enchantment.getByName("PROTECTION_ENVIRONMENTAL")
                : Enchantment.values()[0], 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        int cmd = plugin.getConfigManager().getHeartCustomModelData();
        if (cmd > 0) meta.setCustomModelData(cmd);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, HEART_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER, 1);

        item.setItemMeta(meta);
        item.setAmount(Math.max(1, amount));
        return item;
    }

    // -------------------------------------------------------
    //   NEGATIVE HEART ITEM
    // -------------------------------------------------------

    public ItemStack createNegativeHeartItem(int amount) {
        String matStr = plugin.getConfig().getString("negative-heart-item.material", "COAL");
        String name   = plugin.getConfig().getString("negative-heart-item.name", "<dark_gray>🖤 Cursed Heart");
        List<String> loreStr = plugin.getConfig().getStringList("negative-heart-item.lore");
        boolean glow  = plugin.getConfig().getBoolean("negative-heart-item.glow", false);

        ItemStack item = new ItemStack(parseMaterial(matStr, Material.COAL), amount);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse(name));
        meta.lore(loreStr.stream().map(ColorUtil::parse).collect(Collectors.toList()));
        if (glow) {
            meta.addEnchant(Enchantment.values()[0], 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, NEGATIVE_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER, 1);

        item.setItemMeta(meta);
        return item;
    }

    // -------------------------------------------------------
    //   PROTECT ITEM
    // -------------------------------------------------------

    public ItemStack createProtectItem(int amount) {
        String matStr = plugin.getConfig().getString("protect-item.material", "TOTEM_OF_UNDYING");
        String name   = plugin.getConfig().getString("protect-item.name", "<gold>🛡 Heart Shield");
        List<String> loreStr = plugin.getConfig().getStringList("protect-item.lore");
        boolean glow  = plugin.getConfig().getBoolean("protect-item.glow", true);

        ItemStack item = new ItemStack(parseMaterial(matStr, Material.TOTEM_OF_UNDYING), amount);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse(name));
        meta.lore(loreStr.stream().map(ColorUtil::parse).collect(Collectors.toList()));
        if (glow) {
            meta.addEnchant(Enchantment.values()[0], 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, PROTECT_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER, 1);

        item.setItemMeta(meta);
        return item;
    }

    // -------------------------------------------------------
    //   SKULL WITH CUSTOM SKIN
    // -------------------------------------------------------

    public ItemStack createSkullWithSkin(String textureUrl) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta == null) return skull;

        try {
            PlayerProfile profile = plugin.getServer().createPlayerProfile(UUID.randomUUID(), "DxHeart");
            PlayerTextures textures = profile.getTextures();

            URL url;
            if (textureUrl.startsWith("http")) {
                url = new URL(textureUrl);
            } else {
                String decoded = new String(Base64.getDecoder().decode(textureUrl));
                JsonObject json = JsonParser.parseString(decoded).getAsJsonObject();
                String skinUrl = json.getAsJsonObject("textures")
                    .getAsJsonObject("SKIN")
                    .get("url").getAsString();
                url = new URL(skinUrl);
            }

            textures.setSkin(url);
            profile.setTextures(textures);
            meta.setOwnerProfile(profile);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to apply heart skin: " + e.getMessage());
        }

        skull.setItemMeta(meta);
        return skull;
    }

    // -------------------------------------------------------
    //   CHECKS
    // -------------------------------------------------------

    public boolean isHeartItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(
            new org.bukkit.NamespacedKey(plugin, HEART_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER);
    }

    public boolean isNegativeHeartItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(
            new org.bukkit.NamespacedKey(plugin, NEGATIVE_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER);
    }

    public boolean isProtectItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(
            new org.bukkit.NamespacedKey(plugin, PROTECT_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER);
    }

    public boolean hasProtectItem(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (isProtectItem(item)) return true;
        }
        return false;
    }

    public void consumeProtectItem(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isProtectItem(contents[i])) {
                if (contents[i].getAmount() > 1) contents[i].setAmount(contents[i].getAmount() - 1);
                else player.getInventory().setItem(i, null);
                return;
            }
        }
    }

    // -------------------------------------------------------
    //   GIVE
    // -------------------------------------------------------

    public void giveItem(Player player, String type, int amount) {
        ItemStack item = null;
        switch (type.toLowerCase()) {
            case "heart":
            case "heartitem":
                item = createHeartItem(amount); break;
            case "negativeheart":
            case "cursed":
                item = createNegativeHeartItem(amount); break;
            case "protect":
            case "shield":
                item = createProtectItem(amount); break;
            case "revive":
            case "revivebook":
                item = createReviveBook(amount); break;
        }
        if (item != null) {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
            for (ItemStack l : leftover.values()) {
                player.getWorld().dropItem(player.getLocation(), l);
            }
        }
    }


    // -------------------------------------------------------
    //   REVIVE BOOK ITEM
    // -------------------------------------------------------
    private static final String REVIVE_KEY = "dxlifesteal_revive";

    public ItemStack createReviveBook(int amount) {
        ItemStack item = new ItemStack(Material.ENCHANTED_BOOK, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse("<gradient:#00FF00:#008800>📖 Revive Book</gradient>"));
        meta.lore(java.util.Arrays.asList(
            ColorUtil.parse(""),
            ColorUtil.parse("<gray>Right-click on an eliminated"),
            ColorUtil.parse("<gray>player to <green>revive</green> them!"),
            ColorUtil.parse(""),
            ColorUtil.parse("<dark_gray>DxLifeStealCore")
        ));

        meta.addEnchant(Enchantment.values()[0], 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);

        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, REVIVE_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER, 1);

        item.setItemMeta(meta);
        return item;
    }

    public boolean isReviveBook(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(
            new org.bukkit.NamespacedKey(plugin, REVIVE_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER);
    }

    // -------------------------------------------------------
    //   HELPER
    // -------------------------------------------------------

    private Material parseMaterial(String name, Material fallback) {
        try {
            return Material.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Invalid material '" + name + "', using " + fallback.name());
            return fallback;
        }
    }
}
