package dev.dxlifesteal.managers;

import com.google.gson.JsonObject;
import dev.dxlifesteal.DxLifeStealCore;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class DiscordManager {

    private final DxLifeStealCore plugin;

    public DiscordManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void reload() {}

    public void sendKill(String killer, String victim, int hearts) {
        if (!plugin.getConfigManager().isDiscordEnabled()) return;
        if (!plugin.getConfigManager().isDiscordKill()) return;

        JsonObject embed = buildEmbed(
            "⚔ Heart Stolen",
            "**" + killer + "** stole **" + hearts + " ❤ Heart(s)** from **" + victim + "**",
            0xFF4444
        );
        sendWebhook(embed);
    }

    public void sendElimination(String player, String killer) {
        if (!plugin.getConfigManager().isDiscordEnabled()) return;
        if (!plugin.getConfigManager().isDiscordElim()) return;

        JsonObject embed = buildEmbed(
            "💀 Player Eliminated",
            "**" + player + "** has been eliminated by **" + killer + "**",
            0x880000
        );
        sendWebhook(embed);
    }

    public void sendRevive(String reviver, String player) {
        if (!plugin.getConfigManager().isDiscordEnabled()) return;
        if (!plugin.getConfigManager().isDiscordRevive()) return;

        JsonObject embed = buildEmbed(
            "✅ Player Revived",
            "**" + reviver + "** revived **" + player + "**",
            0x00AA00
        );
        sendWebhook(embed);
    }

    public boolean testWebhook() {
        JsonObject embed = buildEmbed(
            "🔔 DxLifeStealCore Test",
            "Webhook connection successful! Plugin is working correctly.",
            0xFF4444
        );
        return sendWebhook(embed);
    }

    private JsonObject buildEmbed(String title, String description, int color) {
        JsonObject embed = new JsonObject();
        embed.addProperty("title", title);
        embed.addProperty("description", description);
        embed.addProperty("color", color);
        embed.addProperty("timestamp", java.time.Instant.now().toString());

        JsonObject footer = new JsonObject();
        footer.addProperty("text", "DxLifeStealCore • by DipuXPro");
        embed.add("footer", footer);

        return embed;
    }

    private boolean sendWebhook(JsonObject embed) {
        String webhookUrl = plugin.getConfigManager().getDiscordWebhook();
        if (webhookUrl == null || webhookUrl.isEmpty() || webhookUrl.contains("YOUR_WEBHOOK")) return false;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                com.google.gson.JsonArray embeds = new com.google.gson.JsonArray();
                embeds.add(embed);

                JsonObject payload = new JsonObject();
                payload.addProperty("username", "DxLifeStealCore");
                payload.add("embeds", embeds);

                URL url = new URL(webhookUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                String json = new com.google.gson.Gson().toJson(payload);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }

                conn.getResponseCode();
                conn.disconnect();
            } catch (Exception e) {
                if (plugin.getConfigManager().isDebugMode()) {
                    plugin.getLogger().warning("Discord webhook failed: " + e.getMessage());
                }
            }
        });
        return true;
    }
}
