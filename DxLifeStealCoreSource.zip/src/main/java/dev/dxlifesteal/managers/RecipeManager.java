package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

public class RecipeManager {

    private final DxLifeStealCore plugin;

    private NamespacedKey heartKey;
    private NamespacedKey negativeHeartKey;
    private NamespacedKey protectKey;
    private NamespacedKey reviveBookKey;

    public RecipeManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void registerRecipes() {
        heartKey     = new NamespacedKey(plugin, "heart_item");
        negativeHeartKey = new NamespacedKey(plugin, "negative_heart_item");
        protectKey   = new NamespacedKey(plugin, "protect_item");
        reviveBookKey = new NamespacedKey(plugin, "revive_book_item");

        registerHeartRecipe();
        registerNegativeHeartRecipe();
        registerProtectRecipe();
        registerReviveBookRecipe();

        plugin.getLogger().info("[DxLifeStealCore] Recipes registered!");
    }

    // -------------------------------------------------------
    //   HEART ITEM RECIPE
    //   Hard but achievable:
    //
    //   G N G
    //   N D N
    //   G N G
    //
    //   G = Gold Block
    //   N = Nether Star
    //   D = Dragon Egg  (rarest obtainable item)
    //   Result: 1 Heart
    // -------------------------------------------------------
    private void registerHeartRecipe() {
        ItemStack result = plugin.getItemManager().createHeartItem(1);
        ShapedRecipe recipe = new ShapedRecipe(heartKey, result);

        recipe.shape("GNG", "NDN", "GNG");
        recipe.setIngredient('G', Material.GOLD_BLOCK);
        recipe.setIngredient('N', Material.NETHER_STAR);
        recipe.setIngredient('D', Material.DRAGON_EGG);

        plugin.getServer().addRecipe(recipe);
    }

    // -------------------------------------------------------
    //   NEGATIVE HEART RECIPE
    //   Medium-hard:
    //
    //   W W W
    //   W S W
    //   W W W
    //
    //   W = Wither Skeleton Skull
    //   S = Soul Sand
    //   Result: 1 Cursed Heart
    // -------------------------------------------------------
    private void registerNegativeHeartRecipe() {
        ItemStack result = plugin.getItemManager().createNegativeHeartItem(1);
        ShapedRecipe recipe = new ShapedRecipe(negativeHeartKey, result);

        recipe.shape("WWW", "WSW", "WWW");
        recipe.setIngredient('W', Material.WITHER_SKELETON_SKULL);
        recipe.setIngredient('S', Material.SOUL_SAND);

        plugin.getServer().addRecipe(recipe);
    }

    // -------------------------------------------------------
    //   HEART PROTECT (SHIELD) RECIPE
    //   Hard:
    //
    //   T G T
    //   G D G
    //   T G T
    //
    //   T = Totem of Undying
    //   G = Ghast Tear
    //   D = Diamond Block
    //   Result: 1 Heart Shield
    // -------------------------------------------------------
    private void registerProtectRecipe() {
        ItemStack result = plugin.getItemManager().createProtectItem(1);
        ShapedRecipe recipe = new ShapedRecipe(protectKey, result);

        recipe.shape("TGT", "GDG", "TGT");
        recipe.setIngredient('T', Material.TOTEM_OF_UNDYING);
        recipe.setIngredient('G', Material.GHAST_TEAR);
        recipe.setIngredient('D', Material.DIAMOND_BLOCK);

        plugin.getServer().addRecipe(recipe);
    }

    public void unregisterRecipes() {
        plugin.getServer().removeRecipe(heartKey);
        plugin.getServer().removeRecipe(negativeHeartKey);
        plugin.getServer().removeRecipe(protectKey);
        plugin.getServer().removeRecipe(reviveBookKey);
    }

    // -------------------------------------------------------
    //   REVIVE BOOK RECIPE
    //   Hard:
    //
    //   E T E
    //   T B T
    //   E T E
    //
    //   E = Emerald Block
    //   T = Totem of Undying
    //   B = Written Book (with any writing)
    //   Result: 1 Revive Book
    // -------------------------------------------------------
    private void registerReviveBookRecipe() {
        ItemStack result = plugin.getItemManager().createReviveBook(1);
        ShapedRecipe recipe = new ShapedRecipe(reviveBookKey, result);

        recipe.shape("ETE", "TBT", "ETE");
        recipe.setIngredient('E', Material.EMERALD_BLOCK);
        recipe.setIngredient('T', Material.TOTEM_OF_UNDYING);
        recipe.setIngredient('B', Material.WRITTEN_BOOK);

        plugin.getServer().addRecipe(recipe);
    }

}