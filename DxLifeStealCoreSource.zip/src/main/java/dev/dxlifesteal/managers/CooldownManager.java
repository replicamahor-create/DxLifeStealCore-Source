package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {

    private final DxLifeStealCore plugin;
    private final Map<UUID, Long> stealCooldowns = new HashMap<>();
    private final Map<UUID, Long> useCooldowns = new HashMap<>();

    public CooldownManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public boolean canSteal(UUID uuid) {
        int cooldown = plugin.getConfigManager().getStealCooldown();
        if (cooldown <= 0) return true;
        long last = stealCooldowns.getOrDefault(uuid, 0L);
        return System.currentTimeMillis() - last >= cooldown * 1000L;
    }

    public long getStealCooldownLeft(UUID uuid) {
        long last = stealCooldowns.getOrDefault(uuid, 0L);
        long cooldown = plugin.getConfigManager().getStealCooldown() * 1000L;
        long diff = cooldown - (System.currentTimeMillis() - last);
        return Math.max(0, diff / 1000);
    }

    public void setStealCooldown(UUID uuid) {
        stealCooldowns.put(uuid, System.currentTimeMillis());
    }

    public boolean canUse(UUID uuid) {
        int cooldown = plugin.getConfigManager().getUseCooldown();
        if (cooldown <= 0) return true;
        long last = useCooldowns.getOrDefault(uuid, 0L);
        return System.currentTimeMillis() - last >= cooldown * 1000L;
    }

    public long getUseCooldownLeft(UUID uuid) {
        long last = useCooldowns.getOrDefault(uuid, 0L);
        long cooldown = plugin.getConfigManager().getUseCooldown() * 1000L;
        long diff = cooldown - (System.currentTimeMillis() - last);
        return Math.max(0, diff / 1000);
    }

    public void setUseCooldown(UUID uuid) {
        useCooldowns.put(uuid, System.currentTimeMillis());
    }
}
