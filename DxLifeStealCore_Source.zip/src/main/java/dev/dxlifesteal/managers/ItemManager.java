package dev.dxlifesteal.managers;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.dxlifesteal.DxLifeStealCore;
import dev.dxlifesteal.utils.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class ItemManager {

    private final DxLifeStealCore plugin;
    private static final String HEART_KEY = "dxlifesteal_heart";
    private static final String PROTECT_KEY = "dxlifesteal_protect";
    private static final String TIER1_KEY = "dxlifesteal_tier1";
    private static final String TIER2_KEY = "dxlifesteal_tier2";
    private static final String TIER3_KEY = "dxlifesteal_tier3";

    public ItemManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void reload() {}

    // -------------------------------------------------------
    //   HEART ITEM
    // -------------------------------------------------------

    public ItemStack createHeartItem(int amount) {
        String materialStr = plugin.getConfigManager().getHeartMaterial();
        String skinUrl = plugin.getConfigManager().getHeartSkinUrl();

        ItemStack item;
        if (skinUrl != null && !skinUrl.isEmpty()) {
            item = createSkullWithSkin(skinUrl);
        } else {
            Material mat = parseMaterial(materialStr, Material.NETHER_STAR);
            item = new ItemStack(mat, amount);
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse(plugin.getConfigManager().getHeartName()));
        meta.lore(plugin.getConfigManager().getHeartLore()
            .stream().map(ColorUtil::parse).collect(Collectors.toList()));

        if (plugin.getConfigManager().isHeartGlow()) {
            meta.addEnchant(Enchantment.getByName("PROTECTION_ENVIRONMENTAL") != null
                ? Enchantment.getByName("PROTECTION_ENVIRONMENTAL")
                : Enchantment.values()[0], 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        int cmd = plugin.getConfigManager().getHeartCustomModelData();
        if (cmd > 0) meta.setCustomModelData(cmd);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, HEART_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER, 1);

        item.setItemMeta(meta);
        item.setAmount(Math.max(1, amount));
        return item;
    }

    // -------------------------------------------------------
    //   PROTECT ITEM
    // -------------------------------------------------------

    public ItemStack createProtectItem(int amount) {
        String matStr = plugin.getConfig().getString("protect-item.material", "TOTEM_OF_UNDYING");
        String name   = plugin.getConfig().getString("protect-item.name", "<gold>🛡 Heart Shield");
        List<String> loreStr = plugin.getConfig().getStringList("protect-item.lore");
        boolean glow  = plugin.getConfig().getBoolean("protect-item.glow", true);

        ItemStack item = new ItemStack(parseMaterial(matStr, Material.TOTEM_OF_UNDYING), amount);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse(name));
        meta.lore(loreStr.stream().map(ColorUtil::parse).collect(Collectors.toList()));
        if (glow) {
            meta.addEnchant(Enchantment.values()[0], 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, PROTECT_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER, 1);

        item.setItemMeta(meta);
        return item;
    }

    // -------------------------------------------------------
    //   SKULL WITH CUSTOM SKIN
    // -------------------------------------------------------

    public ItemStack createSkullWithSkin(String textureUrl) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta == null) return skull;

        try {
            PlayerProfile profile = plugin.getServer().createPlayerProfile(UUID.randomUUID(), "DxHeart");
            PlayerTextures textures = profile.getTextures();

            URL url;
            if (textureUrl.startsWith("http")) {
                url = new URL(textureUrl);
            } else {
                String decoded = new String(Base64.getDecoder().decode(textureUrl));
                JsonObject json = JsonParser.parseString(decoded).getAsJsonObject();
                String skinUrl = json.getAsJsonObject("textures")
                    .getAsJsonObject("SKIN")
                    .get("url").getAsString();
                url = new URL(skinUrl);
            }

            textures.setSkin(url);
            profile.setTextures(textures);
            meta.setOwnerProfile(profile);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to apply heart skin: " + e.getMessage());
        }

        skull.setItemMeta(meta);
        return skull;
    }

    // -------------------------------------------------------
    //   CHECKS
    // -------------------------------------------------------

    public boolean isHeartItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(
            new org.bukkit.NamespacedKey(plugin, HEART_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER);
    }

    // -------------------------------------------------------
    //   HEART TIER ITEMS
    // -------------------------------------------------------

    public ItemStack createHeartTierItem(int tier, int amount) {
        String path = "heart-tiers.tier" + tier;
        String matStr = plugin.getConfig().getString(path + ".material", tier == 1 ? "NETHER_STAR" : tier == 2 ? "DIAMOND" : "EMERALD");
        String name   = plugin.getConfig().getString(path + ".name", "❤ Heart Tier " + tier);
        List<String> loreStr = plugin.getConfig().getStringList(path + ".lore");
        boolean glow  = plugin.getConfig().getBoolean(path + ".glow", true);
        String key    = tier == 1 ? TIER1_KEY : tier == 2 ? TIER2_KEY : TIER3_KEY;

        Material mat = parseMaterial(matStr, Material.NETHER_STAR);
        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse(name));
        if (!loreStr.isEmpty()) {
            meta.lore(loreStr.stream().map(ColorUtil::parse).collect(Collectors.toList()));
        }
        if (glow) {
            meta.addEnchant(Enchantment.values()[0], 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);
        }
        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, key),
            org.bukkit.persistence.PersistentDataType.INTEGER, tier);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isHeartTierItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        var pdc = meta.getPersistentDataContainer();
        return pdc.has(new org.bukkit.NamespacedKey(plugin, TIER1_KEY), org.bukkit.persistence.PersistentDataType.INTEGER)
            || pdc.has(new org.bukkit.NamespacedKey(plugin, TIER2_KEY), org.bukkit.persistence.PersistentDataType.INTEGER)
            || pdc.has(new org.bukkit.NamespacedKey(plugin, TIER3_KEY), org.bukkit.persistence.PersistentDataType.INTEGER);
    }

    public int getHeartTierAmount(ItemStack item) {
        if (item == null) return 0;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return 0;
        var pdc = meta.getPersistentDataContainer();
        // returns the tier number stored = hearts to give
        if (pdc.has(new org.bukkit.NamespacedKey(plugin, TIER1_KEY), org.bukkit.persistence.PersistentDataType.INTEGER))
            return plugin.getConfigManager().getHeartTier1Amount();
        if (pdc.has(new org.bukkit.NamespacedKey(plugin, TIER2_KEY), org.bukkit.persistence.PersistentDataType.INTEGER))
            return plugin.getConfigManager().getHeartTier2Amount();
        if (pdc.has(new org.bukkit.NamespacedKey(plugin, TIER3_KEY), org.bukkit.persistence.PersistentDataType.INTEGER))
            return plugin.getConfigManager().getHeartTier3Amount();
        return 0;
    }

    public boolean isProtectItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(
            new org.bukkit.NamespacedKey(plugin, PROTECT_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER);
    }

    public boolean hasProtectItem(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (isProtectItem(item)) return true;
        }
        return false;
    }

    public void consumeProtectItem(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isProtectItem(contents[i])) {
                if (contents[i].getAmount() > 1) contents[i].setAmount(contents[i].getAmount() - 1);
                else player.getInventory().setItem(i, null);
                return;
            }
        }
    }

    // -------------------------------------------------------
    //   GIVE
    // -------------------------------------------------------

    public void giveItem(Player player, String type, int amount) {
        ItemStack item = null;
        switch (type.toLowerCase()) {
            case "heart":
            case "heartitem":
                item = createHeartItem(amount); break;
            case "protect":
            case "shield":
                item = createProtectItem(amount); break;
            case "revive":
            case "revivebook":
                item = createReviveBook(amount); break;
            case "tier1":
            case "hearttier1":
                item = createHeartTierItem(1, amount); break;
            case "tier2":
            case "hearttier2":
                item = createHeartTierItem(2, amount); break;
            case "tier3":
            case "hearttier3":
                item = createHeartTierItem(3, amount); break;
        }
        if (item != null) {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
            for (ItemStack l : leftover.values()) {
                player.getWorld().dropItem(player.getLocation(), l);
            }
        }
    }


    // -------------------------------------------------------
    //   REVIVE BOOK ITEM
    // -------------------------------------------------------
    private static final String REVIVE_KEY = "dxlifesteal_revive";

    public ItemStack createReviveBook(int amount) {
        ItemStack item = new ItemStack(Material.ENCHANTED_BOOK, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse("<gradient:#00FF44:#00AA22>📖 Book of Revival</gradient>"));
        meta.lore(java.util.Arrays.asList(
            ColorUtil.parse(""),
            ColorUtil.parse("<dark_gray>┃ <white>Written in the blood of the"),
            ColorUtil.parse("<dark_gray>┃ <white>brave. One page holds the power"),
            ColorUtil.parse("<dark_gray>┃ <white>to restore a fallen soul."),
            ColorUtil.parse(""),
            ColorUtil.parse("<dark_gray>┃ <gray>Effect: <green>Revives eliminated player"),
            ColorUtil.parse("<dark_gray>┃ <gray>Range: <white>5 blocks"),
            ColorUtil.parse("<dark_gray>┃ <gray>Type: <white>Single Use"),
            ColorUtil.parse(""),
            ColorUtil.parse("<green>» <white>Right-Click <green>near eliminated player"),
            ColorUtil.parse(""),
            ColorUtil.parse("<dark_gray>DxLifeStealCore <gray>• <white>DipuXPro")
        ));

        meta.addEnchant(Enchantment.values()[0], 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);

        meta.getPersistentDataContainer().set(
            new org.bukkit.NamespacedKey(plugin, REVIVE_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER, 1);

        item.setItemMeta(meta);
        return item;
    }

    public boolean isReviveBook(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(
            new org.bukkit.NamespacedKey(plugin, REVIVE_KEY),
            org.bukkit.persistence.PersistentDataType.INTEGER);
    }

    // -------------------------------------------------------
    //   HELPER
    // -------------------------------------------------------

    private Material parseMaterial(String name, Material fallback) {
        try {
            return Material.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Invalid material '" + name + "', using " + fallback.name());
            return fallback;
        }
    }
}
