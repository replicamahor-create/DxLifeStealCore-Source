package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.*;

public class HeartManager {

    private final DxLifeStealCore plugin;

    // In-memory cache (loaded from YML on join)
    private final Map<UUID, Integer> hearts = new HashMap<>();
    private final Map<UUID, Integer> maxHearts = new HashMap<>();
    private final Map<UUID, Boolean> frozen = new HashMap<>();
    private final Map<UUID, Boolean> bypassed = new HashMap<>();
    private final Map<UUID, Boolean> eliminated = new HashMap<>();
    private final Map<UUID, Integer> kills = new HashMap<>();
    private final Map<UUID, Integer> deaths = new HashMap<>();
    private final Map<UUID, Integer> eliminations = new HashMap<>();
    private final Map<UUID, Set<UUID>> reviveImmunity = new HashMap<>();

    public HeartManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void reload() {}

    // -------------------------------------------------------
    //   LOAD FROM YML
    // -------------------------------------------------------

    public void loadPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        FileConfiguration cfg = plugin.getDatabaseManager().loadPlayer(uuid);

        // Store player name for leaderboard
        cfg.set("name", player.getName());

        hearts.put(uuid, cfg.getInt("hearts", plugin.getConfigManager().getStartingHearts()));
        maxHearts.put(uuid, cfg.getInt("max-hearts", plugin.getConfigManager().getMaxHearts()));
        frozen.put(uuid, cfg.getBoolean("frozen", false));
        bypassed.put(uuid, cfg.getBoolean("bypassed", false));
        eliminated.put(uuid, cfg.getBoolean("eliminated", false));
        kills.put(uuid, cfg.getInt("kills", 0));
        deaths.put(uuid, cfg.getInt("deaths", 0));
        eliminations.put(uuid, cfg.getInt("eliminations", 0));

        // Load streak
        plugin.getStreakManager().loadStreak(uuid,
            cfg.getInt("streak", 0),
            cfg.getInt("best-streak", 0));

        // Apply hearts to player
        applyHearts(player);

        plugin.getDatabaseManager().markDirty(uuid);
    }

    // -------------------------------------------------------
    //   FLUSH CACHE TO YML (called every second for online players)
    // -------------------------------------------------------

    public void flushToYml(UUID uuid) {
        FileConfiguration cfg = plugin.getDatabaseManager().getPlayerConfig(uuid);
        if (cfg == null) return;

        cfg.set("hearts", getHearts(uuid));
        cfg.set("max-hearts", getMaxHearts(uuid));
        cfg.set("frozen", isFrozen(uuid));
        cfg.set("bypassed", isBypassed(uuid));
        cfg.set("eliminated", isEliminated(uuid));
        cfg.set("kills", getKills(uuid));
        cfg.set("deaths", getDeaths(uuid));
        cfg.set("eliminations", getEliminations(uuid));
        cfg.set("streak", plugin.getStreakManager().getStreak(uuid));
        cfg.set("best-streak", plugin.getStreakManager().getBestStreak(uuid));

        plugin.getDatabaseManager().markDirty(uuid);
    }

    // -------------------------------------------------------
    //   SAVE ON QUIT
    // -------------------------------------------------------

    public void savePlayer(Player player) {
        UUID uuid = player.getUniqueId();
        flushToYml(uuid);
        plugin.getDatabaseManager().savePlayer(uuid);
        plugin.getDatabaseManager().unloadPlayer(uuid);

        // Remove from cache
        hearts.remove(uuid);
        maxHearts.remove(uuid);
        frozen.remove(uuid);
        bypassed.remove(uuid);
        eliminated.remove(uuid);
        kills.remove(uuid);
        deaths.remove(uuid);
        eliminations.remove(uuid);
    }

    public void saveAll() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            flushToYml(player.getUniqueId());
        }
        plugin.getDatabaseManager().saveAll();
    }

    // -------------------------------------------------------
    //   HEART OPERATIONS
    // -------------------------------------------------------

    public void setHearts(UUID uuid, int amount) {
        int min = plugin.getConfigManager().getMinHearts();
        int max = getMaxHearts(uuid);
        amount = Math.max(min, Math.min(max, amount));
        hearts.put(uuid, amount);

        Player player = plugin.getServer().getPlayer(uuid);
        if (player != null) applyHearts(player);

        flushToYml(uuid);
    }

    public void addHearts(UUID uuid, int amount) {
        setHearts(uuid, getHearts(uuid) + amount);
        plugin.getDatabaseManager().logHistory(uuid, "GAIN", amount, null);
    }

    public void removeHearts(UUID uuid, int amount) {
        setHearts(uuid, getHearts(uuid) - amount);
        plugin.getDatabaseManager().logHistory(uuid, "LOSE", amount, null);

        if (getHearts(uuid) <= 0) {
            Player player = plugin.getServer().getPlayer(uuid);
            if (player != null) {
                plugin.getEliminationManager().eliminate(player, null);
            }
        }
    }

    public void stealHeart(Player killer, Player victim) {
        if (isFrozen(victim.getUniqueId()) || isFrozen(killer.getUniqueId())) return;
        if (isBypassed(victim.getUniqueId())) return;

        // Steal chance check
        int chance = plugin.getConfigManager().getStealChance();
        if (chance < 100 && new Random().nextInt(100) >= chance) return;

        // Heart protect check
        if (plugin.getItemManager().hasProtectItem(victim)) {
            plugin.getItemManager().consumeProtectItem(victim);
            plugin.getMessageManager().send(killer, "hearts.protect-victim", "%player%", victim.getName());
            plugin.getMessageManager().send(victim, "hearts.protect-used");
            return;
        }

        int stealAmount = plugin.getConfigManager().getStealAmount();

        // Event multiplier
        if (plugin.getEventManager().isDoubleHeartsActive()) {
            stealAmount *= plugin.getConfigManager().getDoubleHeartsMultiplier();
        }

        // VIP multiplier
        if (killer.hasPermission("dxlifesteal.multiplier.3x")) stealAmount *= 3;
        else if (killer.hasPermission("dxlifesteal.multiplier.2x")) stealAmount *= 2;

        int killerMax = getMaxHearts(killer.getUniqueId());
        int killerCurrent = getHearts(killer.getUniqueId());
        int actualGain = Math.min(stealAmount, killerMax - killerCurrent);

        if (actualGain > 0) {
            hearts.put(killer.getUniqueId(), killerCurrent + actualGain);
            applyHearts(killer);
            plugin.getDatabaseManager().logHistory(killer.getUniqueId(), "STEAL", actualGain, victim.getUniqueId());
            flushToYml(killer.getUniqueId());
        }

        // Remove from victim
        removeHearts(victim.getUniqueId(), stealAmount);
        plugin.getDatabaseManager().logHistory(victim.getUniqueId(), "STOLEN", stealAmount, killer.getUniqueId());

        // Stats
        kills.merge(killer.getUniqueId(), 1, Integer::sum);
        deaths.merge(victim.getUniqueId(), 1, Integer::sum);
        flushToYml(killer.getUniqueId());
        flushToYml(victim.getUniqueId());

        String amountStr = String.valueOf(stealAmount);

        // Messages
        plugin.getMessageManager().send(killer, "hearts.steal.killer",
            "%amount%", amountStr, "%victim%", victim.getName(),
            "%hearts%", String.valueOf(getHearts(killer.getUniqueId())));
        plugin.getMessageManager().send(victim, "hearts.steal.victim",
            "%amount%", amountStr, "%killer%", killer.getName(),
            "%hearts%", String.valueOf(getHearts(victim.getUniqueId())));
        plugin.getMessageManager().broadcast("hearts.steal.broadcast",
            "%amount%", amountStr, "%killer%", killer.getName(), "%victim%", victim.getName());

        // Titles
        plugin.getMessageManager().sendTitle(killer,
            "titles.heart-steal.killer.title", "titles.heart-steal.killer.subtitle",
            "%amount%", amountStr, "%victim%", victim.getName());
        plugin.getMessageManager().sendTitle(victim,
            "titles.heart-steal.victim.title", "titles.heart-steal.victim.subtitle",
            "%amount%", amountStr, "%killer%", killer.getName());

        // Discord
        plugin.getDiscordManager().sendKill(killer.getName(), victim.getName(), stealAmount);

        // Last heart warning
        if (getHearts(victim.getUniqueId()) == 1) {
            plugin.getMessageManager().sendTitle(victim,
                "hearts.last-heart.title", "hearts.last-heart.subtitle");
            victim.playSound(victim.getLocation(), org.bukkit.Sound.BLOCK_BELL_USE, 1.0f, 1.0f);
        }

        // Streak
        plugin.getStreakManager().addKill(killer, victim);
    }

    public void applyHearts(Player player) {
        int h = getHearts(player.getUniqueId());
        double maxHp = Math.max(1, h) * 2.0;

        try {
            var attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
            if (attr != null) {
                attr.setBaseValue(maxHp);
                if (player.getHealth() > maxHp) player.setHealth(maxHp);
            }
        } catch (Exception e) {
            if (plugin.getConfigManager().isDebugMode()) {
                plugin.getLogger().warning("applyHearts error for " + player.getName() + ": " + e.getMessage());
            }
        }
    }

    // -------------------------------------------------------
    //   FLAGS
    // -------------------------------------------------------

    public void setFrozen(UUID uuid, boolean value) {
        frozen.put(uuid, value);
        flushToYml(uuid);
    }

    public void setBypassed(UUID uuid, boolean value) {
        bypassed.put(uuid, value);
        flushToYml(uuid);
    }

    public void setEliminated(UUID uuid, boolean value) {
        eliminated.put(uuid, value);
        flushToYml(uuid);
    }

    public void addElimination(UUID uuid) {
        eliminations.merge(uuid, 1, Integer::sum);
        flushToYml(uuid);
    }

    // -------------------------------------------------------
    //   REVIVE IMMUNITY
    // -------------------------------------------------------

    public void addReviveImmunity(UUID uuid) {
        reviveImmunity.put(uuid, new HashSet<>());
        int secs = plugin.getConfigManager().getReviveImmunity();
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            reviveImmunity.remove(uuid), secs * 20L);
    }

    public boolean hasReviveImmunity(UUID uuid) {
        return reviveImmunity.containsKey(uuid);
    }

    // -------------------------------------------------------
    //   MAX HEARTS
    // -------------------------------------------------------

    public void setMaxHearts(UUID uuid, int amount) {
        maxHearts.put(uuid, Math.max(1, amount));
        Player p = plugin.getServer().getPlayer(uuid);
        if (p != null) applyHearts(p);
        flushToYml(uuid);
    }

    public void addMaxHearts(UUID uuid, int amount) { setMaxHearts(uuid, getMaxHearts(uuid) + amount); }
    public void removeMaxHearts(UUID uuid, int amount) { setMaxHearts(uuid, getMaxHearts(uuid) - amount); }

    // -------------------------------------------------------
    //   GETTERS
    // -------------------------------------------------------

    public int getHearts(UUID uuid) { return hearts.getOrDefault(uuid, plugin.getConfigManager().getStartingHearts()); }
    public int getMaxHearts(UUID uuid) { return maxHearts.getOrDefault(uuid, plugin.getConfigManager().getMaxHearts()); }
    public boolean isFrozen(UUID uuid) { return frozen.getOrDefault(uuid, false); }
    public boolean isBypassed(UUID uuid) { return bypassed.getOrDefault(uuid, false); }
    public boolean isEliminated(UUID uuid) { return eliminated.getOrDefault(uuid, false); }

    public Map<UUID, Boolean> getAllEliminated() { return Collections.unmodifiableMap(eliminated); }
    public int getKills(UUID uuid) { return kills.getOrDefault(uuid, 0); }
    public int getDeaths(UUID uuid) { return deaths.getOrDefault(uuid, 0); }
    public int getEliminations(UUID uuid) { return eliminations.getOrDefault(uuid, 0); }
}
