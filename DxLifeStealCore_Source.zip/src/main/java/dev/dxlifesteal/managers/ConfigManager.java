package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {

    private final DxLifeStealCore plugin;
    private FileConfiguration config;

    public ConfigManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
        this.config = plugin.getConfig();
    }

    public void reload() {
        plugin.reloadConfig();
        this.config = plugin.getConfig();
    }

    // Heart Settings
    public int getStartingHearts() { return config.getInt("hearts.starting", 10); }
    public int getMinHearts() { return config.getInt("hearts.minimum", 2); }
    public int getMaxHearts() { return config.getInt("hearts.maximum", 20); }
    public int getStealAmount() { return config.getInt("hearts.steal-amount", 1); }
    public int getLoseAmount() { return config.getInt("hearts.lose-amount", 1); }
    public int getStealChance() { return config.getInt("hearts.steal-chance", 100); }
    public boolean isPvpOnly() { return config.getBoolean("hearts.pvp-only", true); }
    public boolean isPerWorldEnabled() { return config.getBoolean("hearts.per-world.enabled", false); }
    public int getWorldStartingHearts(String world) {
        return config.getInt("hearts.per-world.worlds." + world, getStartingHearts());
    }

    // Cooldowns
    public int getStealCooldown() { return config.getInt("cooldowns.heart-steal", 0); }
    public int getUseCooldown() { return config.getInt("cooldowns.heart-use", 5); }

    // Elimination
    public String getEliminationMode() { return config.getString("elimination.mode", "BAN"); }
    public String getBanDuration() { return config.getString("elimination.ban-duration", "3d"); }
    public String getEliminationCommand() { return config.getString("elimination.command", ""); }
    public boolean isClearInventory() { return config.getBoolean("elimination.clear-inventory", false); }
    public boolean isClearEnderChest() { return config.getBoolean("elimination.clear-enderchest", false); }
    public boolean isElimSpawnEnabled() { return config.getBoolean("elimination.spawn-location.enabled", false); }

    // Revive
    public boolean isReviveEnabled() { return config.getBoolean("revive.enabled", true); }
    public int getReviveCost() { return config.getInt("revive.cost-hearts", 5); }
    public int getReviveImmunity() { return config.getInt("revive.immunity-seconds", 30); }
    public boolean isReviveAnnounce() { return config.getBoolean("revive.announce", true); }

    // Heart Item
    public String getHeartMaterial() { return config.getString("heart-item.material", "NETHER_STAR"); }
    public String getHeartName() { return config.getString("heart-item.name", "<red>❤ Heart"); }
    public java.util.List<String> getHeartLore() { return config.getStringList("heart-item.lore"); }
    public boolean isHeartGlow() { return config.getBoolean("heart-item.glow", true); }
    public int getHeartCustomModelData() { return config.getInt("heart-item.custom-model-data", 0); }
    public String getHeartSkinUrl() { return config.getString("heart-item.skin-url", ""); }

    // Leaderboard
    public int getLeaderboardSize() { return config.getInt("leaderboard.size", 10); }
    public int getLeaderboardRefresh() { return config.getInt("leaderboard.refresh-interval", 300); }

    // Database
    public String getDatabaseType() { return config.getString("database.type", "SQLITE"); }
    public String getMySQLHost() { return config.getString("database.mysql.host", "localhost"); }
    public int getMySQLPort() { return config.getInt("database.mysql.port", 3306); }
    public String getMySQLDatabase() { return config.getString("database.mysql.database", "dxlifesteal"); }
    public String getMySQLUsername() { return config.getString("database.mysql.username", "root"); }
    public String getMySQLPassword() { return config.getString("database.mysql.password", ""); }
    public int getMySQLPoolSize() { return config.getInt("database.mysql.pool-size", 10); }

    // Discord
    public boolean isDiscordEnabled() { return config.getBoolean("discord.enabled", false); }
    public String getDiscordWebhook() { return config.getString("discord.webhook-url", ""); }
    public boolean isDiscordKill() { return config.getBoolean("discord.events.kill", true); }
    public boolean isDiscordElim() { return config.getBoolean("discord.events.elimination", true); }
    public boolean isDiscordRevive() { return config.getBoolean("discord.events.revive", true); }

    // Streak
    public boolean isStreakEnabled() { return config.getBoolean("streak.enabled", true); }
    public java.util.Map<Integer, Integer> getStreakRewards() {
        java.util.Map<Integer, Integer> rewards = new java.util.LinkedHashMap<>();
        if (config.getConfigurationSection("streak.rewards") != null) {
            for (String key : config.getConfigurationSection("streak.rewards").getKeys(false)) {
                try {
                    rewards.put(Integer.parseInt(key), config.getInt("streak.rewards." + key));
                } catch (NumberFormatException ignored) {}
            }
        }
        return rewards;
    }

    // Events
    public int getDoubleHeartsMultiplier() { return config.getInt("events.double-hearts.multiplier", 2); }
    public int getHeartRainAmount() { return config.getInt("events.heart-rain.amount", 1); }
    public int getHeartRainInterval() { return config.getInt("events.heart-rain.interval", 30); }

    // License
    public String getLicenseKey() { return config.getString("license.key", ""); }
    public int getLicenseGracePeriod() { return config.getInt("license.offline-grace-period", 24); }

    // Misc
    public boolean isMetricsEnabled() { return config.getBoolean("metrics.enabled", true); }
    public boolean isDebugMode() { return config.getBoolean("debug", false); }
    public boolean isPlaceholderAPIEnabled() { return config.getBoolean("placeholders.enabled", true); }

    // Setters (in-game config change) — saves to disk properly
    public void set(String path, Object value) {
        plugin.getConfig().set(path, value);
        this.config = plugin.getConfig();
        plugin.saveConfig();
    }

    // Heart Tier Settings
    public int getHeartTier1Amount() { return config.getInt("heart-tiers.tier1.amount", 1); }
    public int getHeartTier2Amount() { return config.getInt("heart-tiers.tier2.amount", 2); }
    public int getHeartTier3Amount() { return config.getInt("heart-tiers.tier3.amount", 3); }
    public String getHeartTier1Material() { return config.getString("heart-tiers.tier1.material", "NETHER_STAR"); }
    public String getHeartTier2Material() { return config.getString("heart-tiers.tier2.material", "DIAMOND"); }
    public String getHeartTier3Material() { return config.getString("heart-tiers.tier3.material", "EMERALD"); }
    public boolean getHeartTier1Glow() { return config.getBoolean("heart-tiers.tier1.glow", true); }
    public boolean getHeartTier2Glow() { return config.getBoolean("heart-tiers.tier2.glow", true); }
    public boolean getHeartTier3Glow() { return config.getBoolean("heart-tiers.tier3.glow", true); }

    // Storage
    public int getSaveInterval() { return config.getInt("storage.save-interval", 1); }
    public String getDataFolder() { return config.getString("storage.data-folder", "playerdata"); }


    // Death settings
    public boolean isLoseHeartOnMobDeath() { return config.getBoolean("hearts.lose-heart-on-mob-death", false); }
    public boolean isLoseHeartOnNaturalDeath() { return config.getBoolean("hearts.lose-heart-on-natural-death", false); }

}