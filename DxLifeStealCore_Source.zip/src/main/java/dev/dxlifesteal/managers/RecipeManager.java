package dev.dxlifesteal.managers;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

public class RecipeManager {

    private final DxLifeStealCore plugin;

    private NamespacedKey heartKey;
    private NamespacedKey protectKey;
    private NamespacedKey reviveBookKey;
    private NamespacedKey tier1Key;
    private NamespacedKey tier2Key;
    private NamespacedKey tier3Key;

    public RecipeManager(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    public void registerRecipes() {
        heartKey         = new NamespacedKey(plugin, "heart_item");
        protectKey       = new NamespacedKey(plugin, "protect_item");
        reviveBookKey    = new NamespacedKey(plugin, "revive_book_item");
        tier1Key         = new NamespacedKey(plugin, "heart_tier1");
        tier2Key         = new NamespacedKey(plugin, "heart_tier2");
        tier3Key         = new NamespacedKey(plugin, "heart_tier3");

        registerHeartRecipe();
        registerProtectRecipe();
        registerReviveBookRecipe();
        registerTier1Recipe();
        registerTier2Recipe();
        registerTier3Recipe();

        plugin.getLogger().info("[DxLifeStealCore] Recipes registered!");
    }

    // -------------------------------------------------------
    //   HEART ITEM RECIPE
    //   Hard but achievable:
    //
    //   G N G
    //   N D N
    //   G N G
    //
    //   G = Gold Block
    //   N = Nether Star
    //   D = Dragon Egg  (rarest obtainable item)
    //   Result: 1 Heart
    // -------------------------------------------------------
    private void registerHeartRecipe() {
        ItemStack result = plugin.getItemManager().createHeartItem(1);
        ShapedRecipe recipe = new ShapedRecipe(heartKey, result);

        recipe.shape("GNG", "NBN", "GNG");
        recipe.setIngredient('G', Material.GOLD_BLOCK);
        recipe.setIngredient('N', Material.NETHER_STAR);
        recipe.setIngredient('B', Material.BEACON);

        plugin.getServer().addRecipe(recipe);
    }

    // -------------------------------------------------------
    //   HEART PROTECT (SHIELD) RECIPE
    //   Hard:
    //
    //   T G T
    //   G D G
    //   T G T
    //
    //   T = Totem of Undying
    //   G = Ghast Tear
    //   D = Diamond Block
    //   Result: 1 Heart Shield
    // -------------------------------------------------------
    private void registerProtectRecipe() {
        ItemStack result = plugin.getItemManager().createProtectItem(1);
        ShapedRecipe recipe = new ShapedRecipe(protectKey, result);

        recipe.shape("TGT", "GDG", "TGT");
        recipe.setIngredient('T', Material.TOTEM_OF_UNDYING);
        recipe.setIngredient('G', Material.GHAST_TEAR);
        recipe.setIngredient('D', Material.DIAMOND_BLOCK);

        plugin.getServer().addRecipe(recipe);
    }

    public void unregisterRecipes() {
        plugin.getServer().removeRecipe(heartKey);
        plugin.getServer().removeRecipe(protectKey);
        plugin.getServer().removeRecipe(reviveBookKey);
        plugin.getServer().removeRecipe(tier1Key);
        plugin.getServer().removeRecipe(tier2Key);
        plugin.getServer().removeRecipe(tier3Key);
    }

    // -------------------------------------------------------
    //   HEART TIER 1 RECIPE
    //   Easy - common materials
    //
    //   N S N
    //   S N S    N = Nether Star, S = Gold Sword
    //   N S N
    //
    //   Result: 1 Heart Shard Tier I (+1 heart)
    // -------------------------------------------------------
    private void registerTier1Recipe() {
        ItemStack result = plugin.getItemManager().createHeartTierItem(1, 1);
        ShapedRecipe recipe = new ShapedRecipe(tier1Key, result);

        recipe.shape("NSN", "SNS", "NSN");
        recipe.setIngredient('N', Material.NETHER_STAR);
        recipe.setIngredient('S', Material.GOLDEN_SWORD);

        plugin.getServer().addRecipe(recipe);
    }

    // -------------------------------------------------------
    //   HEART TIER 2 RECIPE
    //   Medium - diamond materials
    //
    //   D N D
    //   N E N    D = Diamond Block, N = Nether Star, E = End Crystal
    //   D N D
    //
    //   Result: 1 Heart Crystal Tier II (+2 hearts)
    // -------------------------------------------------------
    private void registerTier2Recipe() {
        ItemStack result = plugin.getItemManager().createHeartTierItem(2, 1);
        ShapedRecipe recipe = new ShapedRecipe(tier2Key, result);

        recipe.shape("DND", "NEN", "DND");
        recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        recipe.setIngredient('N', Material.NETHER_STAR);
        recipe.setIngredient('E', Material.END_CRYSTAL);

        plugin.getServer().addRecipe(recipe);
    }

    // -------------------------------------------------------
    //   HEART TIER 3 RECIPE
    //   Hard - endgame materials
    //
    //   E N E
    //   N D N    E = Emerald Block, N = Nether Star, D = Dragon Egg
    //   E N E
    //
    //   Result: 1 Heart Gem Tier III (+3 hearts)
    // -------------------------------------------------------
    private void registerTier3Recipe() {
        ItemStack result = plugin.getItemManager().createHeartTierItem(3, 1);
        ShapedRecipe recipe = new ShapedRecipe(tier3Key, result);

        recipe.shape("ENE", "NRN", "ENE");
        recipe.setIngredient('E', Material.EMERALD_BLOCK);
        recipe.setIngredient('N', Material.NETHER_STAR);
        recipe.setIngredient('R', Material.NETHERITE_BLOCK);

        plugin.getServer().addRecipe(recipe);
    }

    // -------------------------------------------------------
    //   REVIVE BOOK RECIPE
    //   Hard:
    //
    //   E T E
    //   T B T
    //   E T E
    //
    //   E = Emerald Block
    //   T = Totem of Undying
    //   B = Written Book (with any writing)
    //   Result: 1 Revive Book
    // -------------------------------------------------------
    private void registerReviveBookRecipe() {
        ItemStack result = plugin.getItemManager().createReviveBook(1);
        ShapedRecipe recipe = new ShapedRecipe(reviveBookKey, result);

        recipe.shape("ETE", "TBT", "ETE");
        recipe.setIngredient('E', Material.EMERALD_BLOCK);
        recipe.setIngredient('T', Material.TOTEM_OF_UNDYING);
        recipe.setIngredient('B', Material.WRITTEN_BOOK);

        plugin.getServer().addRecipe(recipe);
    }

}