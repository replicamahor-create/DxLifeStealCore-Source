package dev.dxlifesteal.gui;

import dev.dxlifesteal.DxLifeStealCore;
import dev.dxlifesteal.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class RecipesGUI implements Listener {

    private final DxLifeStealCore plugin;

    // GUI Titles
    private static final String MAIN_TITLE   = "<dark_gray>⚗ <gradient:#FF4444:#FF0000>LifeSteal Recipes</gradient>";
    private static final String HEART_TITLE  = "<dark_gray>❤ <gradient:#FF4444:#FF0000>Heart Recipe</gradient>";
    private static final String SHIELD_TITLE = "<dark_gray>🛡 <gradient:#FFD700:#FFA500>Heart Shield Recipe</gradient>";
    private static final String REVIVE_TITLE = "<dark_gray>📖 <gradient:#00FF00:#008800>Revive Book Recipe</gradient>";

    public RecipesGUI(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------
    //   OPEN MAIN MENU — 27 slots, 4 recipe buttons in middle
    // -------------------------------------------------------
    public void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, ColorUtil.parse(MAIN_TITLE));

        ItemStack border = makeItem(Material.BLACK_STAINED_GLASS_PANE, "<dark_gray> ", null);
        for (int i = 0; i < 54; i++) inv.setItem(i, border);

        // Row 1 — Hearts
        // Slot 11 — Heart Shard Tier I
        ItemStack t1Btn = plugin.getItemManager().createHeartTierItem(1, 1);
        setDisplayName(t1Btn, "<red>❤ Heart Shard Recipe <dark_gray>[Tier I]");
        setLore(t1Btn, "<gray>Click to view", "<red>+1 Heart <gray>recipe.");
        inv.setItem(11, t1Btn);

        // Slot 13 — Heart Crystal Tier II
        ItemStack t2Btn = plugin.getItemManager().createHeartTierItem(2, 1);
        setDisplayName(t2Btn, "<aqua>💎 Heart Crystal Recipe <dark_gray>[Tier II]");
        setLore(t2Btn, "<gray>Click to view", "<aqua>+2 Hearts <gray>recipe.");
        inv.setItem(13, t2Btn);

        // Slot 15 — Heart Gem Tier III
        ItemStack t3Btn = plugin.getItemManager().createHeartTierItem(3, 1);
        setDisplayName(t3Btn, "<green>✦ Heart Gem Recipe <dark_gray>[Tier III]");
        setLore(t3Btn, "<gray>Click to view", "<green>+3 Hearts <gray>recipe.");
        inv.setItem(15, t3Btn);

        // Row 2 — Other items
        // Slot 29 — Heart
        ItemStack heartBtn = plugin.getItemManager().createHeartItem(1);
        setDisplayName(heartBtn, "<red>❤ Stolen Heart Recipe");
        setLore(heartBtn, "<gray>Click to view", "<white>Stolen Heart <gray>recipe.");
        inv.setItem(29, heartBtn);

        // Slot 33 — Heart Shield
        ItemStack shieldBtn = plugin.getItemManager().createProtectItem(1);
        setDisplayName(shieldBtn, "<gold>🛡 Heart Shield Recipe");
        setLore(shieldBtn, "<gray>Click to view", "<gold>Heart Shield <gray>recipe.");
        inv.setItem(33, shieldBtn);

        // Slot 31 — Revive Book
        ItemStack reviveBtn = plugin.getItemManager().createReviveBook(1);
        setDisplayName(reviveBtn, "<green>📖 Revive Book Recipe");
        setLore(reviveBtn, "<gray>Click to view", "<green>Revive Book <gray>recipe.");
        inv.setItem(31, reviveBtn);

        player.openInventory(inv);
    }

    // -------------------------------------------------------
    //   OPEN RECIPE VIEW — 27 slot crafting table style
    //
    //   Layout (27 slots, rows of 9):
    //   Row 0: [filler] [filler] [filler] [filler] [filler] [filler] [filler] [filler] [filler]
    //   Row 1: [filler] [s1][s2][s3] [filler] [=>] [RESULT] [filler]
    //   Row 2: [filler] [s4][s5][s6] [filler] [filler] [filler] [filler]
    //   Row 3: [filler] [s7][s8][s9] [filler] [back] [filler] [filler]
    //
    //   3x3 grid slots: 10,11,12 / 19,20,21 / 28... wait 27 slot = 3 rows
    //   Let me use a cleaner 27-slot layout:
    //
    //   Slot indexes (27 total):
    //   0  1  2  3  4  5  6  7  8
    //   9  10 11 12 13 14 15 16 17
    //   18 19 20 21 22 23 24 25 26
    //
    //   Grid at: 9,10,11 / 18,19,20 / ... no - 3x3 fits in:
    //   Cols 1-3 = slots 1,2,3 / 10,11,12 / 19,20,21
    //   Arrow at col 5 = slots 5,14,23
    //   Result at col 7 = slot 16
    //   Back at slot 26
    // -------------------------------------------------------
    private void openRecipeView(Player player, String title,
                                 Material[] grid,   // 9 items (null = air)
                                 ItemStack result) {

        Inventory inv = Bukkit.createInventory(null, 27, ColorUtil.parse(title));

        // Background filler
        ItemStack filler = makeItem(Material.GRAY_STAINED_GLASS_PANE, "<dark_gray> ", null);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        // 3x3 recipe grid
        // Row 0 of grid → inv slots 1,2,3
        // Row 1 of grid → inv slots 10,11,12
        // Row 2 of grid → inv slots 19,20,21
        int[] gridSlots = {1, 2, 3, 10, 11, 12, 19, 20, 21};
        for (int i = 0; i < 9; i++) {
            if (grid[i] != null) {
                inv.setItem(gridSlots[i], new ItemStack(grid[i]));
            } else {
                inv.setItem(gridSlots[i], makeItem(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "<dark_gray> ", null));
            }
        }

        // Arrow (crafting arrow indicator) at slot 5, 14
        ItemStack arrow = makeItem(Material.ARROW, "<gray>➜ Crafts into", null);
        inv.setItem(5, arrow);
        inv.setItem(14, filler);

        // Result item at slot 7
        inv.setItem(7, result);

        // Back button at slot 26
        ItemStack back = makeItem(Material.BARRIER, "<red>← Back", Arrays.asList("<gray>Return to recipes menu"));
        inv.setItem(26, back);

        player.openInventory(inv);
    }

    // -------------------------------------------------------
    //   CLICK HANDLER
    // -------------------------------------------------------
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        String rawTitle = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
            .plainText().serialize(event.getView().title());

        event.setCancelled(true); // Cancel all clicks in our GUIs

        // ── Main Menu clicks ──
        if (rawTitle.contains("LifeSteal Recipes")) {
            int slot = event.getSlot();

            if (slot == 11) openTier1Recipe(player);
            else if (slot == 13) openTier2Recipe(player);
            else if (slot == 15) openTier3Recipe(player);
            else if (slot == 29) openHeartRecipe(player);
            else if (slot == 31) openReviveBookRecipe(player);
            else if (slot == 33) openShieldRecipe(player);
        }

        // ── Recipe View — Back button ──
        if (rawTitle.contains("Recipe") || rawTitle.contains("Heart") || rawTitle.contains("Tier")) {
            if (event.getSlot() == 26) {
                openMainMenu(player);
            }
        }
    }

    // -------------------------------------------------------
    //   INDIVIDUAL RECIPE OPENERS
    // -------------------------------------------------------

    private void openTier1Recipe(Player player) {
        Material[] grid = {
            Material.NETHER_STAR,  Material.GOLDEN_SWORD,  Material.NETHER_STAR,
            Material.GOLDEN_SWORD, Material.NETHER_STAR,   Material.GOLDEN_SWORD,
            Material.NETHER_STAR,  Material.GOLDEN_SWORD,  Material.NETHER_STAR
        };
        openRecipeView(player, "<dark_gray>❤ <gradient:#FF6666:#FF0000>Heart Shard Tier I Recipe</gradient>",
            grid, plugin.getItemManager().createHeartTierItem(1, 1));
    }

    private void openTier2Recipe(Player player) {
        Material[] grid = {
            Material.DIAMOND_BLOCK, Material.NETHER_STAR,  Material.DIAMOND_BLOCK,
            Material.NETHER_STAR,   Material.END_CRYSTAL,  Material.NETHER_STAR,
            Material.DIAMOND_BLOCK, Material.NETHER_STAR,  Material.DIAMOND_BLOCK
        };
        openRecipeView(player, "<dark_gray>💎 <gradient:#00BFFF:#0055FF>Heart Crystal Tier II Recipe</gradient>",
            grid, plugin.getItemManager().createHeartTierItem(2, 1));
    }

    private void openTier3Recipe(Player player) {
        Material[] grid = {
            Material.EMERALD_BLOCK, Material.NETHER_STAR,    Material.EMERALD_BLOCK,
            Material.NETHER_STAR,   Material.NETHERITE_BLOCK, Material.NETHER_STAR,
            Material.EMERALD_BLOCK, Material.NETHER_STAR,    Material.EMERALD_BLOCK
        };
        openRecipeView(player, "<dark_gray>✦ <gradient:#00FF44:#008800>Heart Gem Tier III Recipe</gradient>",
            grid, plugin.getItemManager().createHeartTierItem(3, 1));
    }

    private void openHeartRecipe(Player player) {
        // G N G
        // N D N
        // G N G
        Material[] grid = {
            Material.GOLD_BLOCK,  Material.NETHER_STAR, Material.GOLD_BLOCK,
            Material.NETHER_STAR, Material.BEACON,      Material.NETHER_STAR,
            Material.GOLD_BLOCK,  Material.NETHER_STAR, Material.GOLD_BLOCK
        };
        openRecipeView(player, HEART_TITLE, grid, plugin.getItemManager().createHeartItem(1));
    }

    private void openShieldRecipe(Player player) {
        // T G T
        // G D G
        // T G T
        Material[] grid = {
            Material.TOTEM_OF_UNDYING, Material.GHAST_TEAR,      Material.TOTEM_OF_UNDYING,
            Material.GHAST_TEAR,       Material.DIAMOND_BLOCK,   Material.GHAST_TEAR,
            Material.TOTEM_OF_UNDYING, Material.GHAST_TEAR,      Material.TOTEM_OF_UNDYING
        };
        openRecipeView(player, SHIELD_TITLE, grid, plugin.getItemManager().createProtectItem(1));
    }

    private void openReviveBookRecipe(Player player) {
        // E T E
        // T B T
        // E T E
        Material[] grid = {
            Material.EMERALD_BLOCK,    Material.TOTEM_OF_UNDYING, Material.EMERALD_BLOCK,
            Material.TOTEM_OF_UNDYING, Material.WRITTEN_BOOK,     Material.TOTEM_OF_UNDYING,
            Material.EMERALD_BLOCK,    Material.TOTEM_OF_UNDYING, Material.EMERALD_BLOCK
        };
        openRecipeView(player, REVIVE_TITLE, grid, plugin.getItemManager().createReviveBook(1));
    }

    // -------------------------------------------------------
    //   ITEM HELPERS
    // -------------------------------------------------------

    private ItemStack makeItem(Material mat, String name, java.util.List<String> loreList) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.displayName(ColorUtil.parse(name));
        if (loreList != null) {
            meta.lore(loreList.stream()
                .map(ColorUtil::parse)
                .collect(java.util.stream.Collectors.toList()));
        }
        item.setItemMeta(meta);
        return item;
    }

    private void setDisplayName(ItemStack item, String name) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.displayName(ColorUtil.parse(name));
        item.setItemMeta(meta);
    }

    private void setLore(ItemStack item, String... lines) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;
        meta.lore(Arrays.stream(lines)
            .map(ColorUtil::parse)
            .collect(java.util.stream.Collectors.toList()));
        item.setItemMeta(meta);
    }
}
