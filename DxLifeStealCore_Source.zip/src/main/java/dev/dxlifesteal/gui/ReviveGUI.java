package dev.dxlifesteal.gui;

import dev.dxlifesteal.DxLifeStealCore;
import dev.dxlifesteal.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ReviveGUI implements Listener {

    private final DxLifeStealCore plugin;

    private static final String TITLE_PREFIX = "§4☠ §cEliminated Players §8| §7Page ";
    private static final int PAGE_SIZE = 45;
    private static final int INV_SIZE  = 54;

    private final Map<UUID, Integer> playerPages = new HashMap<>();

    public ReviveGUI(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    private List<UUID> getEliminatedList() {
        List<UUID> list = new ArrayList<>();
        for (Map.Entry<UUID, Boolean> entry : plugin.getHeartManager().getAllEliminated().entrySet()) {
            if (Boolean.TRUE.equals(entry.getValue())) {
                list.add(entry.getKey());
            }
        }
        return list;
    }

    public void open(Player player) {
        openPage(player, 0);
    }

    public void openPage(Player player, int page) {
        List<UUID> eliminatedList = getEliminatedList();

        if (eliminatedList.isEmpty()) {
            player.sendMessage(ColorUtil.parse(
                "<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] " +
                "<green>✔ There are no eliminated players right now!"));
            return;
        }

        int totalPages = (int) Math.ceil((double) eliminatedList.size() / PAGE_SIZE);
        if (page < 0) page = 0;
        if (page >= totalPages) page = totalPages - 1;

        playerPages.put(player.getUniqueId(), page);

        String title = TITLE_PREFIX + (page + 1) + " §8/ §7" + totalPages;
        Inventory inv = Bukkit.createInventory(null, INV_SIZE, title);

        int start = page * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, eliminatedList.size());
        int reviverHearts = plugin.getHeartManager().getHearts(player.getUniqueId());
        int cost = plugin.getConfigManager().getReviveCost();

        for (int i = start; i < end; i++) {
            UUID uuid = eliminatedList.get(i);
            OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
            String name = op.getName() != null ? op.getName() : uuid.toString().substring(0, 8);

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                meta.setOwningPlayer(op);
                meta.displayName(ColorUtil.parse("<red>☠ <white>" + name));
                meta.lore(List.of(
                    ColorUtil.parse(""),
                    ColorUtil.parse("<dark_gray>┃ <gray>Status: <red>Eliminated"),
                    ColorUtil.parse("<dark_gray>┃ <gray>Revive Cost: <red>❤ " + cost + " hearts"),
                    ColorUtil.parse("<dark_gray>┃ <gray>Your Hearts: <white>❤ " + reviverHearts),
                    ColorUtil.parse(""),
                    reviverHearts >= cost
                        ? ColorUtil.parse("<green>» Click to revive <white>" + name)
                        : ColorUtil.parse("<red>✘ Not enough hearts to revive!")
                ));
                head.setItemMeta(meta);
            }
            inv.setItem(i - start, head);
        }

        ItemStack filler = makeFiller();
        for (int i = (end - start); i < PAGE_SIZE; i++) {
            inv.setItem(i, filler);
        }

        // Bottom row navigation
        if (page > 0) {
            inv.setItem(45, makeNavItem(Material.ARROW,
                "<yellow>« Previous Page",
                "<gray>Go to page <white>" + page));
        } else {
            inv.setItem(45, filler);
        }

        inv.setItem(46, filler);
        inv.setItem(47, filler);
        inv.setItem(48, filler);
        inv.setItem(49, makeInfoItem(page + 1, totalPages, eliminatedList.size()));
        inv.setItem(50, filler);
        inv.setItem(51, filler);
        inv.setItem(52, filler);

        if (page < totalPages - 1) {
            inv.setItem(53, makeNavItem(Material.ARROW,
                "<yellow>Next Page »",
                "<gray>Go to page <white>" + (page + 2)));
        } else {
            inv.setItem(53, filler);
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity human = event.getWhoClicked();
        if (!(human instanceof Player)) return;
        Player player = (Player) human;

        String title = event.getView().getTitle();
        if (title == null || !title.startsWith(TITLE_PREFIX)) return;

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        int slot = event.getSlot();
        int currentPage = playerPages.getOrDefault(player.getUniqueId(), 0);

        if (slot == 45 && clicked.getType() == Material.ARROW) {
            openPage(player, currentPage - 1);
            return;
        }
        if (slot == 53 && clicked.getType() == Material.ARROW) {
            openPage(player, currentPage + 1);
            return;
        }

        if (slot >= PAGE_SIZE) return;
        if (clicked.getType() != Material.PLAYER_HEAD) return;

        ItemMeta meta = clicked.getItemMeta();
        if (meta == null) return;

        SkullMeta skullMeta = (SkullMeta) meta;
        OfflinePlayer target = skullMeta.getOwningPlayer();
        if (target == null) return;

        player.closeInventory();
        playerPages.remove(player.getUniqueId());

        String targetName = target.getName() != null ? target.getName() : "Unknown";

        if (!plugin.getHeartManager().isEliminated(target.getUniqueId())) {
            player.sendMessage(ColorUtil.parse(
                "<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] " +
                "<red>⚠ <white>" + targetName + " <red>is no longer eliminated!"));
            return;
        }

        Player targetOnline = Bukkit.getPlayer(target.getUniqueId());
        if (targetOnline != null) {
            plugin.getEliminationManager().revive(player, targetOnline);
        } else {
            reviveOffline(player, target);
        }
    }

    private void reviveOffline(Player reviver, OfflinePlayer target) {
        if (!plugin.getConfigManager().isReviveEnabled()) {
            plugin.getMessageManager().send(reviver, "revive.disabled");
            return;
        }

        int cost = plugin.getConfigManager().getReviveCost();
        int reviverHearts = plugin.getHeartManager().getHearts(reviver.getUniqueId());
        String targetName = target.getName() != null ? target.getName() : "Unknown";

        if (reviverHearts < cost) {
            plugin.getMessageManager().send(reviver, "revive.not-enough-hearts",
                "%cost%", String.valueOf(cost),
                "%player%", targetName,
                "%hearts%", String.valueOf(reviverHearts));
            return;
        }

        plugin.getHeartManager().removeHearts(reviver.getUniqueId(), cost);
        Bukkit.getBanList(org.bukkit.BanList.Type.NAME).pardon(targetName);
        plugin.getHeartManager().setEliminated(target.getUniqueId(), false);
        plugin.getHeartManager().setHearts(target.getUniqueId(), plugin.getConfigManager().getStartingHearts());

        plugin.getDatabaseManager().logHistory(target.getUniqueId(), "REVIVED", 0, reviver.getUniqueId());

        plugin.getMessageManager().send(reviver, "revive.success-reviver",
            "%player%", targetName, "%cost%", String.valueOf(cost));

        if (plugin.getConfigManager().isReviveAnnounce()) {
            plugin.getMessageManager().broadcast("revive.broadcast",
                "%reviver%", reviver.getName(),
                "%player%", targetName,
                "%cost%", String.valueOf(cost));
        }

        plugin.getDiscordManager().sendRevive(reviver.getName(), targetName);
    }

    private ItemStack makeFiller() {
        ItemStack item = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(ColorUtil.parse("<gray> "));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack makeNavItem(Material mat, String name, String loreLine) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(ColorUtil.parse(name));
            meta.lore(List.of(ColorUtil.parse(loreLine)));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack makeInfoItem(int page, int totalPages, int totalPlayers) {
        ItemStack item = new ItemStack(Material.BOOK);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(ColorUtil.parse("<white>Page <yellow>" + page + " <white>/ <yellow>" + totalPages));
            meta.lore(List.of(
                ColorUtil.parse(""),
                ColorUtil.parse("<gray>Total Eliminated: <red>" + totalPlayers),
                ColorUtil.parse("")
            ));
            item.setItemMeta(meta);
        }
        return item;
    }
}
