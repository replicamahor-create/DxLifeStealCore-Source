package dev.dxlifesteal.listeners;

import dev.dxlifesteal.DxLifeStealCore;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class HeartItemListener implements Listener {

    private final DxLifeStealCore plugin;

    // Players who have activated their Heart Shield
    public static final Set<UUID> shieldActive = new HashSet<>();

    public HeartItemListener(DxLifeStealCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() == EquipmentSlot.OFF_HAND) return;
        if (!event.getAction().name().contains("RIGHT_CLICK")) return;

        ItemStack item = event.getItem();
        if (item == null) return;

        Player player = event.getPlayer();

        // -------------------------------------------------------
        //   HEART ITEM
        // -------------------------------------------------------
        if (plugin.getItemManager().isHeartItem(item)) {
            event.setCancelled(true);

            if (!plugin.getCooldownManager().canUse(player.getUniqueId())) {
                long left = plugin.getCooldownManager().getUseCooldownLeft(player.getUniqueId());
                plugin.getMessageManager().send(player, "items.cooldown", "%seconds%", String.valueOf(left));
                return;
            }

            int current = plugin.getHeartManager().getHearts(player.getUniqueId());
            int max = plugin.getHeartManager().getMaxHearts(player.getUniqueId());
            if (current >= max) {
                plugin.getMessageManager().send(player, "hearts.max-reached", "%max%", String.valueOf(max));
                return;
            }

            plugin.getCooldownManager().setUseCooldown(player.getUniqueId());
            plugin.getHeartManager().addHearts(player.getUniqueId(), 1);

            // Consume item (skip in creative mode)
            if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
                if (item.getAmount() > 1) item.setAmount(item.getAmount() - 1);
                else player.getInventory().setItemInMainHand(null);
            }

            plugin.getMessageManager().send(player, "items.used",
                "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(player.getUniqueId())));

            // TOTEM FATA EFFECT
            playTotemPopEffect(player);
        }

        // -------------------------------------------------------
        //   HEART TIER ITEMS (Tier I +1, Tier II +2, Tier III +3)
        // -------------------------------------------------------
        else if (plugin.getItemManager().isHeartTierItem(item)) {
            event.setCancelled(true);

            if (!plugin.getCooldownManager().canUse(player.getUniqueId())) {
                long left = plugin.getCooldownManager().getUseCooldownLeft(player.getUniqueId());
                plugin.getMessageManager().send(player, "items.cooldown", "%seconds%", String.valueOf(left));
                return;
            }

            int currentHearts = plugin.getHeartManager().getHearts(player.getUniqueId());
            int maxHearts = plugin.getHeartManager().getMaxHearts(player.getUniqueId());
            int heartsToAdd = plugin.getItemManager().getHeartTierAmount(item);

            if (currentHearts >= maxHearts) {
                plugin.getMessageManager().send(player, "items.max-hearts");
                return;
            }

            plugin.getCooldownManager().setUseCooldown(player.getUniqueId());
            plugin.getHeartManager().addHearts(player.getUniqueId(), heartsToAdd);

            if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
                if (item.getAmount() > 1) item.setAmount(item.getAmount() - 1);
                else player.getInventory().setItemInMainHand(null);
            }

            plugin.getMessageManager().send(player, "items.used",
                "%hearts%", String.valueOf(plugin.getHeartManager().getHearts(player.getUniqueId())));

            playTotemPopEffect(player);
        }

        // -------------------------------------------------------
        //   REVIVE BOOK - Right click to open Revive GUI
        // -------------------------------------------------------
        else if (plugin.getItemManager().isReviveBook(item)) {
            event.setCancelled(true);

            // Open the Revive GUI — shows all eliminated players with their heads
            plugin.getReviveGUI().open(player);
        }

        // -------------------------------------------------------
        //   HEART SHIELD - Right click to activate
        // -------------------------------------------------------
        else if (plugin.getItemManager().isProtectItem(item)) {
            event.setCancelled(true);

            if (shieldActive.contains(player.getUniqueId())) {
                player.sendMessage(dev.dxlifesteal.utils.ColorUtil.parse(
                    "<dark_gray>[<gradient:#FF4444:#FF0000>DxLifeSteal</gradient><dark_gray>] " +
                    "<gold>🛡 <yellow>Heart Shield is already <white>ACTIVE<yellow>!"));
                return;
            }

            // Activate shield — remove item from inventory
            if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
                if (item.getAmount() > 1) item.setAmount(item.getAmount() - 1);
                else player.getInventory().setItemInMainHand(null);
            }

            shieldActive.add(player.getUniqueId());

            // Notify player
            player.sendMessage(dev.dxlifesteal.utils.ColorUtil.parse(""));
            player.sendMessage(dev.dxlifesteal.utils.ColorUtil.parse(
                "  <gold>🛡 <gradient:#FFD700:#FF8C00>Heart Shield Activated!</gradient>"));
            player.sendMessage(dev.dxlifesteal.utils.ColorUtil.parse(
                "  <gray>Your next death in PvP will <gold>not cost a heart<gray>."));
            player.sendMessage(dev.dxlifesteal.utils.ColorUtil.parse(""));

            // Shield glow effect
            player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING,
                player.getLocation().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.1);
            player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 0.7f, 1.5f);
        }
    }

    // -------------------------------------------------------
    //   TOTEM FATA EFFECT - No inventory, no item, pure effect
    // -------------------------------------------------------
    private void playTotemPopEffect(Player player) {

        // Trigger exact totem screen animation via reflection
        // Status byte 35 = totem resurrection animation in Minecraft protocol
        try {
            // Get NMS player handle
            Object nmsPlayer = player.getClass().getMethod("getHandle").invoke(player);

            // Find connection field (works across versions via reflection)
            Object connection = null;
            for (java.lang.reflect.Field f : nmsPlayer.getClass().getFields()) {
                String typeName = f.getType().getSimpleName();
                if (typeName.contains("Connection") || typeName.contains("NetworkManager")
                    || typeName.contains("PlayerConnection")) {
                    f.setAccessible(true);
                    connection = f.get(nmsPlayer);
                    break;
                }
            }

            if (connection == null) {
                // Try superclass fields
                for (java.lang.reflect.Field f : nmsPlayer.getClass().getSuperclass().getFields()) {
                    f.setAccessible(true);
                    Object val = f.get(nmsPlayer);
                    if (val != null && val.getClass().getSimpleName().toLowerCase().contains("connect")) {
                        connection = val;
                        break;
                    }
                }
            }

            // Find packet class
            Class<?> packetClass = null;
            for (String name : new String[]{
                "net.minecraft.network.protocol.game.ClientboundEntityEventPacket",
                "net.minecraft.network.protocol.game.PacketPlayOutEntityStatus"}) {
                try { packetClass = Class.forName(name); break; }
                catch (ClassNotFoundException ignored) {}
            }

            if (packetClass != null && connection != null) {
                // Create packet: entity + status 35 (totem pop)
                Object packet = packetClass.getConstructors()[0].newInstance(nmsPlayer, (byte) 35);

                // Send packet via send/a/sendPacket method
                for (java.lang.reflect.Method m : connection.getClass().getMethods()) {
                    if (m.getParameterCount() == 1 &&
                        m.getParameterTypes()[0].isAssignableFrom(packetClass)) {
                        m.invoke(connection, packet);
                        break;
                    }
                }
            }
        } catch (Exception ignored) {
            // Silent fallback - particles only if packet fails
        }

        // Always run these - they work on all versions
        // TOTEM_OF_UNDYING particle = the actual screen orange flash effect
        player.getWorld().spawnParticle(
            Particle.TOTEM_OF_UNDYING,
            player.getLocation().add(0, 1, 0),
            150, 0.6, 1.0, 0.6, 0.5
        );

        // Real totem potion effects
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 40, 1, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1, false, true));

        // Step 6: Red heart spiral around player
        new BukkitRunnable() {
            double angle = 0;
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= 20) { cancel(); return; }

                for (int i = 0; i < 2; i++) {
                    double x = Math.cos(angle + i * Math.PI) * 0.8;
                    double z = Math.sin(angle + i * Math.PI) * 0.8;
                    player.getWorld().spawnParticle(
                        Particle.HEART,
                        player.getLocation().add(x, 1.2, z),
                        1, 0, 0, 0, 0
                    );
                }

                // Red rising dust
                Particle.DustOptions redDust = new Particle.DustOptions(Color.RED, 1.5f);
                player.getWorld().spawnParticle(Particle.DUST,
                    player.getLocation().add(
                        (Math.random() - 0.5) * 1.2,
                        Math.random() * 2.2,
                        (Math.random() - 0.5) * 1.2),
                    1, 0, 0, 0, 0, redDust);

                angle += Math.PI / 5;
                ticks++;
            }
        }.runTaskTimer(plugin, 2L, 1L);

        // Step 7: Sounds - exactly like totem pop
        player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1.0f, 1.0f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f), 8L);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.5f, 2.0f), 15L);

        // Step 8: White flash at end
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            Particle.DustOptions whiteDust = new Particle.DustOptions(Color.WHITE, 2.0f);
            player.getWorld().spawnParticle(Particle.DUST,
                player.getLocation().add(0, 1, 0),
                30, 0.5, 0.5, 0.5, 0, whiteDust);
        }, 18L);
    }


}